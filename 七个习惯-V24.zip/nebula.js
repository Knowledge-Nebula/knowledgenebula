/* Original ambient rendering of the existing seven-habit groups. No input capture. */
(function(){
 'use strict';
 let cleanup=()=>{},update=()=>{};
 const groups=['self','people','energy'];
 const colors=[[112,173,199],[190,153,106],[117,172,139]];
 function mount(motion=true){
  cleanup();
  const canvas=document.createElement('canvas');canvas.className='home-nebula';canvas.setAttribute('aria-hidden','true');document.body.prepend(canvas);
  const ctx=canvas.getContext('2d');if(!ctx){canvas.remove();return;}
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  let seed=2707;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  let w=0,h=0,dpr=1,raf=0,last=0,time=0,visible=true,disposed=false,active=-1,glow=[0,0,0],enabled=motion;
  const dust=Array.from({length:1800},(_,i)=>({x:random(),y:random(),r:.25+random()*.95,a:.12+random()*.6,phase:random()*Math.PI*2,group:i%3}));
  const stars=Array.from({length:145},()=>({x:random(),y:random(),r:.45+random()*.8,a:.13+random()*.55}));
  // Positions interpret the existing three groups; small particles are atmospheric only.
  const centers=[[.24,.30],[.78,.48],[.39,.82]];
  const anchors={h1:[.10,.20],h2:[.30,.13],h3:[.25,.43],h4:[.68,.19],h5:[.87,.40],h6:[.72,.65],h7:[.37,.82]};
  const nodes=window.STAR_MAP_DATA.nodes,byId=new Map(nodes.map(n=>[n.id,n]));
  function habit(n){let depth=0;while(n&&depth++<12){if(anchors[n.id])return n.id;n=byId.get(n.parent);}return null;}
  const points=new Map();
  for(const n of nodes){const id=habit(n);if(!id)continue;const base=anchors[id],angle=random()*Math.PI*2,r=n.id===id?0:.035+random()*.1;points.set(n.id,{x:base[0]+Math.cos(angle)*r,y:base[1]+Math.sin(angle)*r*.75,major:n.id===id,group:+id[1]<4?0:+id[1]<7?1:2});}
  const edges=(window.STAR_MAP_DATA.links||[]).filter(e=>points.has(e.source)&&points.has(e.target));
  // Daylight retains a small subset of real parent-child links, with no decorative dust.
  const dayIds=new Set(Object.keys(anchors));
  for(const id of Object.keys(anchors))nodes.filter(n=>n.parent===id).slice(0,2).forEach(n=>dayIds.add(n.id));
  const dayEdges=edges.filter(e=>dayIds.has(e.source)&&dayIds.has(e.target));
  function rgba(rgb,a){return `rgba(${rgb.join(',')},${Math.max(0,Math.min(1,a))})`;}
  function haze(x,y,rx,ry,rgb,a){ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);const g=ctx.createRadialGradient(0,0,0,0,0,1);g.addColorStop(0,rgba(rgb,a));g.addColorStop(.35,rgba(rgb,a*.55));g.addColorStop(1,rgba(rgb,0));ctx.fillStyle=g;ctx.fillRect(-1,-1,2,2);ctx.restore();}
  function syncMotionControl(){const button=document.querySelector('[data-nebula-motion]');if(!button)return;const label=media.matches?'已随系统减少动态':enabled?'暂停星云呼吸':'开启星云呼吸';if(button.textContent!==label)button.textContent=label;button.disabled=media.matches;button.setAttribute('aria-pressed',String(!enabled||media.matches));}
  function paintDay(dt){
   const palette=[[127,186,229],[228,197,139],[155,195,224]];
   for(let i=0;i<3;i++){
    glow[i]+=(+(active===i)-glow[i])*Math.min(1,dt?dt/140:1);
    const [x,y]=centers[i],b=enabled&&!media.matches?1+Math.sin(time/3500+i)*.04:1;
    haze(x*w,y*h,w*.44*b,h*.48*b,palette[i],.16+glow[i]*.08);
   }
   for(const [index,e] of dayEdges.entries()){
    const a=points.get(e.source),b=points.get(e.target),g=glow[a.group];
    ctx.strokeStyle=rgba(palette[a.group],.23+g*.25);ctx.lineWidth=.7;
    ctx.beginPath();ctx.moveTo(a.x*w,a.y*h);ctx.lineTo(b.x*w,b.y*h);ctx.stroke();
    // Three quiet moving lights trace real connections; no scattered speckles.
    if(index%7===0){const t=enabled&&!media.matches?(time/12000+index*.13)%1:.4,x=(a.x+(b.x-a.x)*t)*w,y=(a.y+(b.y-a.y)*t)*h;
     haze(x,y,8,8,palette[a.group],.18+g*.14);ctx.fillStyle=rgba(palette[a.group],.65);ctx.beginPath();ctx.arc(x,y,1.2,0,Math.PI*2);ctx.fill();}
   }
   for(const id of dayIds){const p=points.get(id);if(!p)continue;const x=p.x*w,y=p.y*h,g=glow[p.group];
    if(p.major){haze(x,y,18+g*10,18+g*10,palette[p.group],.16+g*.12);ctx.strokeStyle=rgba(palette[p.group],.55+g*.25);ctx.lineWidth=.85;ctx.beginPath();ctx.arc(x,y,3+g,0,Math.PI*2);ctx.stroke();}
    else{ctx.fillStyle=rgba(palette[p.group],.5+g*.25);ctx.beginPath();ctx.arc(x,y,1.1,0,Math.PI*2);ctx.fill();}
   }
   canvas.dataset.region=active<0?'none':groups[active];
  }
  function paint(dt=0){
   syncMotionControl();
   const light=document.body.dataset.theme==='light';
   ctx.clearRect(0,0,w,h);time+=dt;
   if(light){paintDay(dt);return;}
   for(let i=0;i<3;i++){glow[i]+=(+(active===i)-glow[i])*Math.min(1,dt?dt/140:1);const [x,y]=centers[i],b=1+(enabled&&!media.matches?Math.sin(time/2600+i*1.9)*.065:0),rgb=light?[[62,103,121],[156,112,68],[64,119,86]][i]:colors[i];
    haze(x*w,y*h,w*.55*b,h*.54*b,rgb,(light?.15:.17)+glow[i]*.11);
    haze((x+.10)*w,(y-.08)*h,w*.23*b,h*.22*b,rgb,(light?.07:.11)+glow[i]*.12);
   }
   // Overlapping wisps give the dust lane an irregular, cloud-like silhouette.
   for(let i=0;i<11;i++){const x=i/10,y=.5+Math.sin(x*6.1-1.3)*.20,g=i<4?0:i<8?1:2,b=enabled&&!media.matches?Math.sin(time/3200+i)*.015:0;haze(x*w,(y+b)*h,w*(.11+(i%3)*.025),h*(.09+(i%4)*.013),light?[[62,103,121],[156,112,68],[64,119,86]][g]:colors[g],(light?.028:.055)+glow[g]*.04);}
   // A broad, broken dust lane crosses the full viewport and dissolves into its edges.
   for(const p of dust){const x=p.x*w,curve=.50+Math.sin(p.x*6.1-1.3)*.20,y=(curve+(p.y-.5)*.46)*h;
    const edge=Math.pow(Math.sin(p.y*Math.PI),2),density=Math.max(0,1-Math.abs(p.y-.5)*2),rgb=light?[66,87,80]:colors[p.group];
    const a=p.a*edge*density*(light?.32:.65)*(1+glow[p.group]*1.6);
    const offset=enabled&&!media.matches?Math.sin(time/3600+p.phase)*2:0;
    ctx.fillStyle=rgba(rgb,a);ctx.beginPath();ctx.arc(x,y+offset,p.r,0,Math.PI*2);ctx.fill();
   }
   for(const s of stars){ctx.fillStyle=rgba(light?[71,86,79]:[215,225,219],s.a*(light?.40:.70));ctx.beginPath();ctx.arc(s.x*w,s.y*h,s.r,0,Math.PI*2);ctx.fill();}
   for(const e of edges){const a=points.get(e.source),b=points.get(e.target);ctx.strokeStyle=rgba(light?[74,99,89]:colors[a.group],(light?.08:.11)+glow[a.group]*.29);ctx.lineWidth=.65;ctx.beginPath();ctx.moveTo(a.x*w,a.y*h);ctx.lineTo(b.x*w,b.y*h);ctx.stroke();}
   for(const p of points.values()){const g=glow[p.group],rgb=light?[69,99,86]:colors[p.group],x=p.x*w,y=p.y*h;if(p.major)haze(x,y,22+g*20,22+g*20,rgb,.13+g*.25);ctx.fillStyle=rgba(rgb,(p.major?.7:.35)+g*.25);ctx.beginPath();ctx.arc(x,y,p.major?2.2+g:1.1,0,Math.PI*2);ctx.fill();}
   canvas.dataset.region=active<0?'none':groups[active];
  }
  function running(){return enabled&&!media.matches&&visible&&!document.hidden;}
  function tick(now){raf=0;if(disposed)return;syncMotionControl();if(!last)last=now;const dt=now-last;if(dt>=32){paint(Math.min(dt,60));last=now;}if(running())raf=requestAnimationFrame(tick);}
  function refresh(value=enabled){enabled=value;cancelAnimationFrame(raf);raf=0;last=0;paint();const button=document.querySelector('[data-nebula-motion]');if(button){button.textContent=media.matches?'已随系统减少动态':enabled?'暂停星云呼吸':'开启星云呼吸';button.disabled=media.matches;button.setAttribute('aria-pressed',String(!enabled||media.matches));}if(running())raf=requestAnimationFrame(tick);}
  function resize(){w=innerWidth;h=innerHeight;dpr=Math.min(devicePixelRatio||1,1.5);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);paint();}
  function activate(e){const a=e.target.closest('[data-nebula-region]');if(a){active=groups.indexOf(a.dataset.nebulaRegion);if(!running()||e.type==='focusin'){glow=groups.map((_,i)=>+(i===active));paint();}}}
  function release(e){if(e.target.closest('[data-nebula-region]')&&!e.relatedTarget?.closest('[data-nebula-region]')){active=-1;if(!running()){glow=[0,0,0];paint();}}}
  const observer=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;refresh();});observer.observe(document.getElementById('home'));
  document.addEventListener('pointerover',activate);document.addEventListener('pointerout',release);document.addEventListener('focusin',activate);document.addEventListener('focusout',release);
  const visibility=()=>refresh(),reduced=()=>refresh();document.addEventListener('visibilitychange',visibility);media.addEventListener('change',reduced);window.addEventListener('resize',resize);
  resize();refresh();update=refresh;
  cleanup=()=>{disposed=true;cancelAnimationFrame(raf);observer.disconnect();canvas.remove();window.removeEventListener('resize',resize);document.removeEventListener('visibilitychange',visibility);media.removeEventListener('change',reduced);document.removeEventListener('pointerover',activate);document.removeEventListener('pointerout',release);document.removeEventListener('focusin',activate);document.removeEventListener('focusout',release);update=()=>{};cleanup=()=>{};};
 }
 window.HomeNebula={mount,refresh:value=>update(value),destroy:()=>cleanup()};
})();
