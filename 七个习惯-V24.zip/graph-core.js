(function(root){
  'use strict';
  const centers=[[0,-360],[330,-270],[475,35],[310,350],[-45,410],[-390,260],[-475,-65],[-300,-330]];
  function prepare(data){
    const nodes=data.nodes.map(n=>({...n,vx:0,vy:0,pinned:false}));
    const byId=new Map(nodes.map(n=>[n.id,n]));
    const groups=nodes.filter(n=>n.parent==='book');
    function depth(n,seen=new Set()){if(!n.parent)return 0;if(seen.has(n.id))throw Error('Graph hierarchy contains a cycle');seen.add(n.id);return 1+depth(byId.get(n.parent),seen);}
    nodes.forEach(n=>{n.depth=depth(n);n.radius=n.id==='book'?12:n.depth===1?9:n.depth===2?5.5:3.8;});
    groups.forEach((g,i)=>{[g.anchorX,g.anchorY]=centers[i%centers.length];g.anchorX*=1.42;g.anchorY*=.72;g.x=g.anchorX;g.y=g.anchorY;});
    const book=byId.get('book');Object.assign(book,{x:0,y:0,anchorX:0,anchorY:0});
    groups.forEach(g=>{
      const all=nodes.filter(n=>n.group===g.id&&n!==g);
      all.forEach((n,i)=>{const angle=i*2.39996+.4;const radius=76+Math.sqrt(i)*27;n.x=g.x+Math.cos(angle)*radius;n.y=g.y+Math.sin(angle)*radius;n.anchorX=g.x;n.anchorY=g.y;});
    });
    const links=nodes.filter(n=>n.parent).map(n=>({source:n.parent,target:n.id,type:'hierarchy',label:'概念层级',reason:'本站按公开资料整理的主题与子概念。'})).concat(data.links.map(l=>({...l,type:'connection'})));
    links.forEach(l=>{if(!byId.has(l.source)||!byId.has(l.target))throw Error('Missing graph endpoint');l.a=byId.get(l.source);l.b=byId.get(l.target);});
    return {nodes,links,byId,groups};
  }
  function neighborhood(graph,id,depth=1,cross=true){
    const seen=new Set([id]);let frontier=[id];
    for(let d=0;d<depth;d++){const next=[];for(const l of graph.links){if(!cross&&l.type==='connection')continue;let other=frontier.includes(l.source)?l.target:frontier.includes(l.target)?l.source:null;if(other&&!seen.has(other)){seen.add(other);next.push(other);}}frontier=next;}
    return seen;
  }
  function visible(graph,options){
    const {group='all',depth=3,local=false,selected='book',hops=1,cross=true}=options;
    if(local)return neighborhood(graph,selected,hops,cross);
    return new Set(graph.nodes.filter(n=>(group==='all'||n.group===group||n.id==='book')&&n.depth<=depth).map(n=>n.id));
  }
  function step(graph,{alpha=1,spacing=1,visibleIds=null}={}){
    const ns=visibleIds?graph.nodes.filter(n=>visibleIds.has(n.id)):graph.nodes;
    for(let i=0;i<ns.length;i++)for(let j=i+1;j<ns.length;j++){
      const a=ns[i],b=ns[j];let dx=b.x-a.x,dy=b.y-a.y;let d=Math.hypot(dx,dy);if(d<.01){dx=.02;dy=.01;d=.023;}
      const minimum=(a.depth<2||b.depth<2?75:48)*spacing;
      const repel=(900*spacing/(d*d+150)+Math.max(0,minimum-d)*.045)*alpha;
      const fx=dx/d*repel,fy=dy/d*repel;a.vx-=fx;a.vy-=fy;b.vx+=fx;b.vy+=fy;
    }
    for(const l of graph.links){if(visibleIds&&(!visibleIds.has(l.source)||!visibleIds.has(l.target)))continue;const a=l.a,b=l.b;const dx=b.x-a.x,dy=b.y-a.y,d=Math.max(1,Math.hypot(dx,dy));const desired=(l.type==='connection'?240:a.id==='book'?Math.hypot(b.anchorX,b.anchorY):b.depth===2?116:74)*spacing;const force=(d-desired)*(l.type==='connection'?.001:.014)*alpha;const fx=dx/d*force,fy=dy/d*force;a.vx+=fx;a.vy+=fy;b.vx-=fx;b.vy-=fy;}
    for(const n of ns){if(n.pinned||n.dragging){n.vx=0;n.vy=0;continue;}const anchor=n.depth<2?.003:.0005;n.vx+=(n.anchorX-n.x)*anchor*alpha;n.vy+=(n.anchorY-n.y)*anchor*alpha;n.vx*=.72;n.vy*=.72;n.x+=Math.max(-8,Math.min(8,n.vx));n.y+=Math.max(-8,Math.min(8,n.vy));}
  }
  root.StarGraphCore={prepare,neighborhood,visible,step};
})(typeof window==='undefined'?globalThis:window);
