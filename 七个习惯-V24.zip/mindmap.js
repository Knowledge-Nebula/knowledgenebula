(function(){
'use strict';
const NS='http://www.w3.org/2000/svg';
function mount(host,{nodes,onSelect,signal}){
 const make=(tag,attrs={})=>{const e=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));return e;};
 const svg=make('svg',{class:'mindmap-svg',tabindex:0,role:'group','aria-label':'知识框架树状导图：点击概念阅读，可平移和缩放'}),world=make('g');svg.append(world);host.replaceChildren(svg);
 let points=[],edges=[],camera={x:0,y:0,k:1},w=1,h=1,active=null,current='book',touch=false;
 const collapsed=new Set();let settings={depth:99,group:'all'};
 const titles={foundation:'前言：观念与原则'},roman=['I','II','III','IV','V','VI','VII'];
 const name=n=>n.id==='book'?'七个习惯':titles[n.id]||(/^h[1-7]$/.test(n.id)?'('+roman[+n.id[1]-1]+') ':'')+n.label;
 const colors={foundation:'#d0be93',h1:'#8fc4b0',h2:'#a6bce0',h3:'#d7bd8c',h4:'#b5bd8b',h5:'#8cc4cb',h6:'#b8a5cb',h7:'#ce9f8c',book:'#e1c98b'};
 function render({depth=99,group='all'}={},keepView=false){
  settings={depth,group};
  const allowed=nodes.filter(n=>n.id==='book'||(n.depth<=depth&&(group==='all'||n.group===group))),byId=new Map(allowed.map(n=>[n.id,n]));
  const children=id=>allowed.filter(n=>n.parent===id),roots=children('book'),left=roots.filter(n=>['foundation','h1','h2','h3'].includes(n.id)),right=roots.filter(n=>!left.includes(n));
  points=[];edges=[];const root={...byId.get('book'),x:0,y:0};points.push(root);
  function branch(n,side,level,cursor){const kids=children(n.id),p={...n,x:side*(level===1?420:420+(level-1)*420),y:0};points.push(p);if(kids.length){const ys=[];for(const kid of kids){const c=branch(kid,side,level+1,cursor);ys.push(c.y);edges.push({a:p,b:c});}p.y=(ys[0]+ys[ys.length-1])/2;}else{p.y=cursor.y;cursor.y+=54;}return p;}
  for(const [list,side] of [[left,-1],[right,1]]){const cursor={y:0},start=points.length;for(const n of list){const p=branch(n,side,1,cursor);edges.push({a:root,b:p});cursor.y+=80;}const offset=(cursor.y-134)/2;points.slice(start).forEach(p=>p.y-=offset);}
  const byNode=new Map(nodes.map(n=>[n.id,n]));const visible=p=>{let parent=p.parent;while(parent){if(collapsed.has(parent))return false;parent=byNode.get(parent)?.parent;}return true;};points=points.filter(visible);const shown=new Set(points.map(p=>p.id));edges=edges.filter(e=>shown.has(e.a.id)&&shown.has(e.b.id));
  world.replaceChildren();for(const edge of edges){edge.el=make('path',{class:'mindmap-branch',fill:'none',stroke:colors[edge.b.group]||colors.book});world.append(edge.el);}
  for(const p of points){const e=make('g',{'data-tree-node':p.id,tabindex:0,role:'button','aria-label':name(p),'aria-pressed':String(p.id===current),class:'mindmap-node'+(p.depth<2?' major':'')});const dot=make('circle',{r:p.id==='book'?8:p.depth===1?5:2.5,fill:colors[p.group]||colors.book});const text=make('text',{'dominant-baseline':'middle',fill:colors[p.group]||'#c2cfdf'});text.textContent=name(p);const hit=make('rect',{class:'mindmap-hit',fill:'transparent',rx:5});e.append(hit,dot,text);world.append(e);p.el=e;p.text=text;p.hit=hit;p.dot=dot;
   if(nodes.some(n=>n.parent===p.id)){const toggle=make('g',{'data-tree-toggle':p.id,role:'button',tabindex:0,'aria-label':(collapsed.has(p.id)?'展开':'收起')+name(p),'aria-expanded':String(!collapsed.has(p.id)),class:'tree-toggle'});toggle.append(make('circle',{r:10,fill:'#182433',stroke:colors[p.group]||colors.book}));const mark=make('text',{'text-anchor':'middle','dominant-baseline':'central',fill:'#edf1f8','font-size':14});mark.textContent=collapsed.has(p.id)?'+':'−';toggle.append(mark);e.append(toggle);p.toggle=toggle;}
  }
  points.forEach(p=>p.baseY=p.y);if(keepView)draw();else fit();const counter=host.parentElement.parentElement.querySelector(".star-live-count");if(counter)counter.textContent=points.length+" 个概念 · "+edges.length+" 条分支";return {nodes:points.length,links:edges.length};
 }
 function size(){const b=host.getBoundingClientRect();w=b.width||1;h=b.height||1;svg.setAttribute('viewBox',`0 0 ${w} ${h}`);}
 function fit(){size();if(!points.length)return;points.forEach(p=>p.y=p.baseY);const xs=points.map(p=>p.x),ys=points.map(p=>p.y),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);camera.k=Math.min(1.2,(w-(w<700?170:300))/Math.max(x1-x0,1),(h-150)/Math.max(y1-y0,1));camera.k=Math.max(.1,camera.k);camera.x=w/2-(x0+x1)/2*camera.k;camera.y=h/2+15-(y0+y1)/2*camera.k;draw();}
 function draw(){const k=camera.k;const indicator=host.parentElement.querySelector('.star-zoom');if(indicator)indicator.textContent=Math.round(k*100)+'%';world.setAttribute('transform',`translate(${camera.x} ${camera.y}) scale(${k})`);for(const e of edges){const mx=(e.a.x+e.b.x)/2;e.el.setAttribute('d',`M${e.a.x},${e.a.y} H${mx} V${e.b.y} H${e.b.x}`);e.el.setAttribute('stroke-width',1/k);}
  for(const p of points){p.el.setAttribute('transform',`translate(${p.x},${p.y})`);const font=Math.min(p.id==='book'?22:p.depth===1?14:11,(p.depth<2?32:24)*k),side=p.x<0?-1:1,dx=p.id==='book'?0:side*11;const y=p.id==='book'?-23:0;p.text.setAttribute('font-size',font/k);p.text.setAttribute('x',dx/k);p.text.setAttribute('y',y/k);p.text.setAttribute('text-anchor',p.id==='book'?'middle':side<0?'end':'start');p.dot.setAttribute('r',(p.id==='book'?8:p.depth===1?5:2.5)/k);const width=name(p).length*font+16;p.hit.setAttribute('x',(p.id==='book'?-width/2:side<0?-width:0)/k);p.hit.setAttribute('y',(y-17)/k);p.hit.setAttribute('width',width/k);p.hit.setAttribute('height',34/k);p.el.classList.toggle('selected',p.id===current);p.el.setAttribute('aria-pressed',p.id===current);p.text.style.opacity='1';if(p.toggle)p.toggle.setAttribute('transform',`translate(${(p.id==='book'?0:side*(width+14))/k},${(p.id==='book'?18:0)/k}) scale(${Math.min(1,k*2)/k})`);}
 }
 function zoom(f,x=w/2,y=h/2){const k=Math.min(3,Math.max(.1,camera.k*f)),r=k/camera.k;camera.x=x-(x-camera.x)*r;camera.y=y-(y-camera.y)*r;camera.k=k;draw();}
 function toggleBranch(id){collapsed.has(id)?collapsed.delete(id):collapsed.add(id);render(settings,true);svg.querySelector('[data-tree-toggle="'+id+'"]')?.focus({preventScroll:true});}
 const listen=(type,fn,options={})=>svg.addEventListener(type,fn,{...options,signal});
 listen('pointerdown',e=>{if(e.button!==0||(e.pointerType==='touch'&&!touch))return;active={id:e.pointerId,x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY,moved:false,toggle:e.target.closest('[data-tree-toggle]')?.dataset.treeToggle,node:e.target.closest('[data-tree-node]')?.dataset.treeNode};svg.setPointerCapture(e.pointerId);});
 listen('pointermove',e=>{if(!active)return;if(Math.hypot(e.clientX-active.x,e.clientY-active.y)>5)active.moved=true;if(active.moved){camera.x+=e.clientX-active.lastX;camera.y+=e.clientY-active.lastY;draw();}active.lastX=e.clientX;active.lastY=e.clientY;});
 let last=0;listen('pointerup',e=>{if(!active)return;const a=active;active=null;last=performance.now();if(svg.hasPointerCapture(e.pointerId))svg.releasePointerCapture(e.pointerId);if(!a.moved){if(a.toggle)toggleBranch(a.toggle);else if(a.node)onSelect(a.node);}});
 listen('pointercancel',()=>{active=null;});listen('click',e=>{const toggle=e.target.closest('[data-tree-toggle]')?.dataset.treeToggle;if(toggle){if(performance.now()-last>250)toggleBranch(toggle);return;}const id=e.target.closest('[data-tree-node]')?.dataset.treeNode;if(id&&performance.now()-last>250)onSelect(id);});
 listen('wheel',e=>{if(!e.shiftKey&&!touch)return;e.preventDefault();const b=svg.getBoundingClientRect();zoom(Math.exp(-e.deltaY*.002),e.clientX-b.left,e.clientY-b.top);},{passive:false});
 listen('keydown',e=>{const toggle=e.target.closest('[data-tree-toggle]')?.dataset.treeToggle;if(toggle&&(e.key==='Enter'||e.key===' ')){e.preventDefault();toggleBranch(toggle);return;}const id=e.target.closest('[data-tree-node]')?.dataset.treeNode;if(id&&(e.key==='Enter'||e.key===' ')){e.preventDefault();onSelect(id);}else if(['+','=','-','0','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();if(e.key==='0')fit();else if(e.key==='+'||e.key==='=')zoom(1.2);else if(e.key==='-')zoom(1/1.2);else{camera.x+=e.key==='ArrowLeft'?40:e.key==='ArrowRight'?-40:0;camera.y+=e.key==='ArrowUp'?40:e.key==='ArrowDown'?-40:0;draw();}}});
 return {snapshot(){return {collapsed:[...collapsed],camera:{...camera},settings:{...settings}};},restore(state){if(!state)return;collapsed.clear();state.collapsed.forEach(id=>collapsed.add(id));render(state.settings);camera={...state.camera};draw();},render,fit,zoom,highlight(id){current=id;draw();},setTouch(value){touch=value;svg.style.touchAction=value?'none':'pan-y pinch-zoom';},focus(id){points.find(p=>p.id===id)?.el.focus({preventScroll:true});}};
}
window.KnowledgeTree={mount};
})();

