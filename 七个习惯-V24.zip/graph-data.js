window.STAR_MAP_DATA = {
  "nodes": [
    {
      "id": "book",
      "label": "高效能人士的七个习惯",
      "group": "book",
      "parent": null,
      "summary": "把个人选择、合作与持续更新放在一起理解；这张图是基于公开资料重新组织的学习导航。",
      "example": "事情很多时，先选一个困扰，再沿相关概念找到可尝试的一步。",
      "prompt": "今天哪个问题最值得带进这张图？",
      "sourceIds": [
        "fc0",
        "notes3"
      ]
    },
    {
      "id": "foundation",
      "label": "底层观念与原则",
      "group": "foundation",
      "parent": "book",
      "summary": "先理解怎样看问题、怎样形成习惯以及怎样维护能力，再进入七个习惯的具体实践。",
      "example": "换了几种日程工具仍很焦虑，先检查自己把什么当作成功。",
      "prompt": "我目前需要新的工具，还是新的理解？",
      "sourceIds": [
        "notes3",
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "principles",
      "label": "以原则为基础",
      "group": "foundation",
      "parent": "foundation",
      "summary": "原则提供判断方向；具体做法要随处境调整，不能把某一种技巧当作所有人的答案。",
      "example": "为了守信，你主动协商延期，而不是为了表面准时交付半成品。",
      "prompt": "这次选择背后，我愿意坚持的原则是什么？",
      "sourceIds": [
        "notes3",
        "notes4"
      ]
    },
    {
      "id": "inside-out",
      "label": "由内而外",
      "group": "foundation",
      "parent": "foundation",
      "summary": "从自己的解释、选择和行动寻找改变入口，同时承认环境与他人也会影响结果。",
      "example": "会议总跑题，你先改写议程和发言方式，再邀请同事共同调整。",
      "prompt": "我可以先改变哪一个与自己有关的环节？",
      "sourceIds": [
        "notes3",
        "mapnotes1"
      ]
    },
    {
      "id": "perspectives",
      "label": "思维方式与视角",
      "group": "foundation",
      "parent": "foundation",
      "summary": "同一事件可能被不同经验解释；先识别自己的假设，再比较其他合理视角。",
      "example": "同事反复追问进度，你先核实他需要什么信息，而不立刻认定是在催促。",
      "prompt": "我把哪些推测当作了已知事实？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "character",
      "label": "品德与技巧",
      "group": "foundation",
      "parent": "foundation",
      "summary": "长期可信的行为是合作基础；表达技巧有帮助，但不能代替诚实、负责与持续实践。",
      "example": "一次流畅的道歉之后，你还需要实际修正导致失约的安排。",
      "prompt": "我说得很好的一件事，有没有行为来支持？",
      "sourceIds": [
        "notes3",
        "mapnotes1"
      ]
    },
    {
      "id": "habit-elements",
      "label": "习惯的三个要素",
      "group": "foundation",
      "parent": "foundation",
      "summary": "形成习惯需要知道为什么做、掌握做法，并有实践意愿；缺一项就值得重新检查。",
      "example": "你知道阅读重要，却一直没开始；问题也许是材料太难，而不是意志薄弱。",
      "prompt": "知识、方法和意愿中，哪一项最缺支持？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "habit-knowledge",
      "label": "知识：理解为何做",
      "group": "foundation",
      "parent": "habit-elements",
      "summary": "先弄清行动要解决什么问题，避免只是跟随流行做法而看不见自己的需要。",
      "example": "你记录时间，不是为了每天更满，而是想知道注意力去了哪里。",
      "prompt": "这个习惯究竟想帮助我解决什么？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "habit-skill",
      "label": "技巧：知道怎样做",
      "group": "foundation",
      "parent": "habit-elements",
      "summary": "把抽象愿望变成可以学习的方法；不会做时，先降低难度并寻找反馈。",
      "example": "想提升倾听，就先练习在对话结束前复述对方最在意的一点。",
      "prompt": "我需要学会哪一个具体动作？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "habit-willingness",
      "label": "意愿：愿意去实践",
      "group": "foundation",
      "parent": "habit-elements",
      "summary": "行动需要与真实意愿连接；先理解阻力与代价，再决定是否承诺尝试。",
      "example": "你发现自己不想坚持某个课程，于是重新确认它是否服务当前目标。",
      "prompt": "这件事是我想做，还是只是觉得应该做？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "maturity",
      "label": "依赖、独立与互赖",
      "group": "foundation",
      "parent": "foundation",
      "summary": "这条主线描述从依靠他人到自我负责，再到有选择地合作；学习可从当下问题进入。",
      "example": "一个项目里，你既要完成自己负责的部分，也需要清楚提出协作请求。",
      "prompt": "此刻需要增强自主，还是建立更好的合作？",
      "sourceIds": [
        "notes3",
        "mapnotes1"
      ]
    },
    {
      "id": "independence",
      "label": "独立：自我负责",
      "group": "foundation",
      "parent": "maturity",
      "summary": "逐步发展选择、判断和执行能力；独立不意味着所有事情都必须独自完成。",
      "example": "你独立决定学习目标，同时向熟悉领域的朋友请教入门路线。",
      "prompt": "我想自己决定哪件事，又需要什么支持？",
      "sourceIds": [
        "notes3",
        "mapnotes1"
      ]
    },
    {
      "id": "interdependence",
      "label": "互赖：有选择地合作",
      "group": "foundation",
      "parent": "maturity",
      "summary": "在保有责任和判断的同时，让不同人的能力彼此配合，形成共同的成果。",
      "example": "你擅长整理资料，同伴擅长讲解，两人明确分工后一起做分享。",
      "prompt": "什么结果值得我们一起完成？",
      "sourceIds": [
        "notes3",
        "mapnotes1"
      ]
    },
    {
      "id": "pc-balance",
      "label": "产出与产能的平衡",
      "group": "foundation",
      "parent": "foundation",
      "summary": "既关注眼前完成的结果，也维护持续做好事情所需的技能、关系、工具和状态。",
      "example": "赶完一次交付后，你留时间修复反复返工的流程，而不是立刻堆入新任务。",
      "prompt": "我是在增加成果，还是消耗产生它的条件？",
      "sourceIds": [
        "notes1",
        "notes4"
      ]
    },
    {
      "id": "h1",
      "label": "积极主动",
      "group": "h1",
      "parent": "book",
      "summary": "从可选择的回应开始，把行动放在能够影响的范围内；这不代表一切结果都由个人负责。",
      "example": "安排突然变化时，你先核实信息，再提出自己能够完成的调整方案。",
      "prompt": "眼下还有哪一个具体选择属于我？",
      "sourceIds": [
        "fc1",
        "notes1"
      ]
    },
    {
      "id": "response-space",
      "label": "刺激与回应之间",
      "group": "h1",
      "parent": "h1",
      "summary": "遇到刺激后，尝试留出辨认和选择的空间；停顿的目的，是让回应更符合你的原则。",
      "example": "看到一条让你不舒服的消息，先写草稿，核实事实后再发送。",
      "prompt": "除了第一反应，我还有怎样的回应？",
      "sourceIds": [
        "fc1",
        "notes1"
      ]
    },
    {
      "id": "four-capacities",
      "label": "四项选择能力",
      "group": "h1",
      "parent": "response-space",
      "summary": "公开笔记把自我觉察、想象、良知与独立意志作为理解主动选择的四个入口。",
      "example": "做决定前，依次看看自己的反应、其他可能、价值取舍和下一步。",
      "prompt": "这次决定中，我最需要调动哪种能力？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "self-awareness",
      "label": "自我觉察",
      "group": "h1",
      "parent": "four-capacities",
      "summary": "观察自己的情绪和想法，分清正在发生的事与自己赋予它的解释。",
      "example": "汇报被打断时，你注意到自己正在把一次追问解释成全盘否定。",
      "prompt": "我现在的感受和判断分别是什么？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "imagination",
      "label": "想象其他可能",
      "group": "h1",
      "parent": "four-capacities",
      "summary": "暂时跳出熟悉反应，设想另一种可行做法；想象提供选择，并不保证结果。",
      "example": "除了立刻答应或拒绝，你想到可以先提出一个较小的试行范围。",
      "prompt": "是否还有一个尚未考虑的选项？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "conscience",
      "label": "良知与价值判断",
      "group": "h1",
      "parent": "four-capacities",
      "summary": "在压力或诱惑下，检查行动是否符合自己认可的原则，并考虑对他人的影响。",
      "example": "为了赶进度想省略说明时，你决定如实告诉协作者哪些信息尚未核实。",
      "prompt": "这个选择是否符合我愿意坚持的原则？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "independent-will",
      "label": "独立意志",
      "group": "h1",
      "parent": "four-capacities",
      "summary": "理解取舍之后，尝试把选择变成行动；必要时也能调整承诺与行动规模。",
      "example": "你为一项重要准备留了半小时，收到普通消息时选择稍后集中回复。",
      "prompt": "我可以用哪个小行动表达自己的决定？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "concern-circle",
      "label": "关注圈",
      "group": "h1",
      "parent": "h1",
      "summary": "关注圈包括你在意的所有事情，其中既有能影响的部分，也有暂时难以改变的部分。",
      "example": "你关注行业变化，但也发现不停刷新消息没有增加可行动的信息。",
      "prompt": "我在意的事情中，哪些只是在消耗注意力？",
      "sourceIds": [
        "notes1",
        "fc1"
      ]
    },
    {
      "id": "influence-circle",
      "label": "影响圈",
      "group": "h1",
      "parent": "concern-circle",
      "summary": "把精力放在确实能够改变或推动的事情上，并通过行动观察影响范围是否变化。",
      "example": "你无法决定招聘节奏，但可以更新作品、寻找反馈并安排下一次联系。",
      "prompt": "今天能推动的一小部分是什么？",
      "sourceIds": [
        "fc1",
        "notes1"
      ]
    },
    {
      "id": "control-range",
      "label": "区分控制范围",
      "group": "h1",
      "parent": "influence-circle",
      "summary": "区分直接行动、通过协作影响和暂时无法改变的事项，给不同问题选择不同回应。",
      "example": "出行延误无法撤销，你可以调整会面方式，并及时与对方协商。",
      "prompt": "这件事属于哪种范围，适合怎样处理？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "proactive-language",
      "label": "主动表达",
      "group": "h1",
      "parent": "h1",
      "summary": "用准确表达看见自己的选择与限制；不把改换措辞当作否认困难的方法。",
      "example": "把“我完全没办法”说具体：我无法更改日期，但能先提交已完成的部分。",
      "prompt": "怎样表达才能同时说明限制与可行行动？",
      "sourceIds": [
        "fc1"
      ]
    },
    {
      "id": "keep-promises",
      "label": "承诺与守信",
      "group": "h1",
      "parent": "h1",
      "summary": "从可兑现的小承诺建立可信度；遇到变化时，及时说明并重新协商。",
      "example": "你答应周五发资料，发现会延期后提前告知，并约定一个可靠的新时间。",
      "prompt": "我当前的承诺是否符合真实容量？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "learn-errors",
      "label": "承认与修正错误",
      "group": "h1",
      "parent": "h1",
      "summary": "区分已经发生的失误与仍可调整的回应，把注意力放在修复、学习和减少重演。",
      "example": "发错版本后，你迅速补发并标明差异，随后改进文件命名方式。",
      "prompt": "现在最有帮助的修复动作是什么？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "h2",
      "label": "以终为始",
      "group": "h2",
      "parent": "book",
      "summary": "在投入行动之前，先明确想抵达的结果，以及希望用怎样的原则走向它。",
      "example": "开始一场讨论前，你先写下希望结束时共同弄清楚的一个问题。",
      "prompt": "如果这件事做好了，我会看到什么变化？",
      "sourceIds": [
        "fc2",
        "notes3"
      ]
    },
    {
      "id": "two-creations",
      "label": "两次创造",
      "group": "h2",
      "parent": "h2",
      "summary": "先形成方向和构想，再投入实际行动；把想做的事与怎样落实区分开来。",
      "example": "整理工作室前，你先确定它主要服务写作还是拍摄，再安排空间。",
      "prompt": "我有没有先弄清楚这件事为何值得做？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "mental-creation",
      "label": "第一次创造：定方向",
      "group": "h2",
      "parent": "two-creations",
      "summary": "用思考、设计与判断形成目标，让行动有一个可以检验和修订的起点。",
      "example": "写文章之前，你先确定读者读完后应该理解什么，再列出结构。",
      "prompt": "开始前，我需要先做清楚哪个决定？",
      "sourceIds": [
        "notes1",
        "mapnotes2"
      ]
    },
    {
      "id": "physical-creation",
      "label": "第二次创造：落实",
      "group": "h2",
      "parent": "two-creations",
      "summary": "把构想投入现实，在执行中观察条件与反馈；实际结果也会帮助你修正最初设想。",
      "example": "课程大纲写好后，你先讲一小节，观察听众是否能跟上。",
      "prompt": "我怎样验证构想在现实里是否成立？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "personal-mission",
      "label": "个人使命宣言",
      "group": "h2",
      "parent": "h2",
      "summary": "用自己的话写明想成为怎样的人、愿意作出什么贡献，让它帮助具体取舍。",
      "example": "你把“希望成为可靠的合作者”写成提醒，用来判断该接多少任务。",
      "prompt": "哪些话能在困难取舍时真正提醒我？",
      "sourceIds": [
        "fc2",
        "notes1"
      ]
    },
    {
      "id": "values-center",
      "label": "价值与原则中心",
      "group": "h2",
      "parent": "personal-mission",
      "summary": "检查决定主要围绕什么展开，让方向来自经过思考的价值，而不只随外界评价变化。",
      "example": "一个机会很受赞赏，但会挤掉你最看重的家庭时间，你重新权衡。",
      "prompt": "如果没有旁人的评价，我还会这样选吗？",
      "sourceIds": [
        "fc2",
        "notes4"
      ]
    },
    {
      "id": "life-roles",
      "label": "看见不同角色",
      "group": "h2",
      "parent": "h2",
      "summary": "识别自己在工作、家庭、学习和照顾自身等领域的责任，避免只看到单一身份。",
      "example": "安排下周时，你除了工作成果，也写下一件重要的个人或关系事务。",
      "prompt": "哪些角色正在被长期忽略？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "role-goals",
      "label": "角色与目标",
      "group": "h2",
      "parent": "life-roles",
      "summary": "把各个角色对应到少量重要结果，帮助使命和价值进入近期可行的安排。",
      "example": "作为学习者，你把“多学习”改成完成一次练习并请人反馈。",
      "prompt": "在一个角色中，最近最重要的结果是什么？",
      "sourceIds": [
        "notes1",
        "notes4"
      ]
    },
    {
      "id": "success-criteria",
      "label": "先描述成功",
      "group": "h2",
      "parent": "h2",
      "summary": "在开始前说清楚什么算有效成果，使投入、协作和后续调整有共同参照。",
      "example": "做活动前，你先确定希望参与者带走什么，而不只盯着报名人数。",
      "prompt": "怎样判断这次努力确实达到了目的？",
      "sourceIds": [
        "fc2",
        "fc6"
      ]
    },
    {
      "id": "mental-rehearsal",
      "label": "心灵演练",
      "group": "h2",
      "parent": "h2",
      "summary": "在行动前设想关键场景和可能回应，把抽象原则转成更容易调用的具体准备。",
      "example": "一场难谈的沟通前，你预想被打断时如何平静地说完重要信息。",
      "prompt": "哪个容易失去方向的瞬间值得提前练习？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "shared-mission",
      "label": "共同使命",
      "group": "h2",
      "parent": "h2",
      "summary": "在共同事务中，让参与者一起澄清目标与原则；共同参与有助于形成真正认同。",
      "example": "几个朋友办读书会时，先讨论是重在交流感受还是完成系统学习。",
      "prompt": "我们以为相同的目标，理解真的一致吗？",
      "sourceIds": [
        "mapnotes1",
        "mapnotes2"
      ]
    },
    {
      "id": "h3",
      "label": "要事第一",
      "group": "h3",
      "parent": "book",
      "summary": "把重要目标落实为时间与行动安排，在真实责任和有限容量之间持续做取舍。",
      "example": "你在日程里先给一项长期准备留位置，再决定还能接受哪些临时要求。",
      "prompt": "我最重要的事情，是否在日程里有位置？",
      "sourceIds": [
        "fc3",
        "notes3"
      ]
    },
    {
      "id": "importance-urgency",
      "label": "重要与紧急",
      "group": "h3",
      "parent": "h3",
      "summary": "紧急看时间压力，重要看它与目标、价值和责任的关系；两者需要分别判断。",
      "example": "一条消息催得很急，但你先核实它是否真的影响今天必须完成的结果。",
      "prompt": "它紧急的理由和重要的理由分别是什么？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "urgent-important",
      "label": "重要且紧急",
      "group": "h3",
      "parent": "importance-urgency",
      "summary": "优先处理真实危机和有期限的重要责任，同时回顾是否有可以提前预防的部分。",
      "example": "明天要提交必要材料，你先补齐缺项，再安排之后的提前提醒。",
      "prompt": "这次必须先做什么，未来能怎样提前？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "important-not-urgent",
      "label": "重要而不紧急",
      "group": "h3",
      "parent": "importance-urgency",
      "summary": "为准备、学习、关系和更新主动预留空间，减少它们被眼前催促持续挤走的情况。",
      "example": "你为下月展示提前做一轮练习，而不是等到最后一晚才开始。",
      "prompt": "哪件不会催我、却会影响未来的事值得安排？",
      "sourceIds": [
        "fc3",
        "notes3"
      ]
    },
    {
      "id": "urgent-not-important",
      "label": "紧急但不重要",
      "group": "h3",
      "parent": "importance-urgency",
      "summary": "对某些打断和临时要求，核实目标、责任与时限，再协商回应方式。",
      "example": "同事说“现在就要”，你问清用途后发现明早反馈也不影响进度。",
      "prompt": "这份急迫感是否对应我的真实责任？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "neither-urgent-important",
      "label": "既不紧急也不重要",
      "group": "h3",
      "parent": "importance-urgency",
      "summary": "辨认与当前目标无关、又无明显恢复价值的消耗；不能把所有休息都归入这一类。",
      "example": "你原想休息十分钟，却不断刷新并更疲惫，于是换一种恢复方式。",
      "prompt": "这件事是在恢复我，还是让我更空耗？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "weekly-plan",
      "label": "以周为单位安排",
      "group": "h3",
      "parent": "h3",
      "summary": "从一周的整体看角色与重要结果，再安排具体时段，避免每天只处理眼前事项。",
      "example": "周末花几分钟看下周，先放入两项重要准备和一段关系时间。",
      "prompt": "下周最值得提前留位置的两件事是什么？",
      "sourceIds": [
        "fc3",
        "notes1"
      ]
    },
    {
      "id": "role-balance",
      "label": "兼顾不同角色",
      "group": "h3",
      "parent": "weekly-plan",
      "summary": "查看时间是否长期只流向一个领域；平衡关注重要责任，不要求每天平均分配。",
      "example": "工作高峰结束后，你主动补上被推迟的学习和陪伴安排。",
      "prompt": "哪个角色最需要我重新分配一点注意力？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "reserve-time",
      "label": "给要事预留时间",
      "group": "h3",
      "parent": "weekly-plan",
      "summary": "把重要事情从愿望变成受保护的时间，并为准备、收尾与突发情况留余地。",
      "example": "你为方案写作留一小时，并提前告诉协作者这段时间会晚些回复。",
      "prompt": "我能为一项要事留出哪一小段确定时间？",
      "sourceIds": [
        "fc3"
      ]
    },
    {
      "id": "say-no",
      "label": "有依据地说不",
      "group": "h3",
      "parent": "h3",
      "summary": "面对超出容量或冲突的要求，说明优先事项与限制，再协商替代方案。",
      "example": "已有两项紧迫承诺时，你提出延后新任务，而不是先全部答应。",
      "prompt": "我要保护的事情是什么，可以怎样说明？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "adapt-plan",
      "label": "每日调整",
      "group": "h3",
      "parent": "weekly-plan",
      "summary": "计划是支持重要结果的工具；新信息出现时，调整做法而不是机械服从日程。",
      "example": "家人需要帮助，你移动学习时段，同时保留一个较小的最低行动。",
      "prompt": "什么变化值得调整，我仍想保留什么？",
      "sourceIds": [
        "notes1",
        "mapnotes1"
      ]
    },
    {
      "id": "result-delegation",
      "label": "以结果为中心授权",
      "group": "h3",
      "parent": "h3",
      "summary": "合作时先说清预期结果与责任，允许对方在合适范围内选择方法。",
      "example": "请同伴整理资料时，你说明使用场景与质量要求，而不逐行规定做法。",
      "prompt": "哪些必须说清，哪些可以交给对方判断？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "delegation-agreement",
      "label": "授权的五项约定",
      "group": "h3",
      "parent": "result-delegation",
      "summary": "对齐结果、边界、资源、检查方式和后果，让自主选择有明确支持与共同预期。",
      "example": "交接任务时，两人确认可用资料、遇阻找谁以及何时一起检查进展。",
      "prompt": "对方是否知道目标、权限和求助方式？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "h4",
      "label": "双赢思维",
      "group": "h4",
      "parent": "book",
      "summary": "在尊重自身需要的同时寻找各方都能接受的利益安排，必要时也允许不达成合作。",
      "example": "协商分工时，你既说明自己的容量，也认真询问对方真正困难的部分。",
      "prompt": "双方各自希望保护的是什么？",
      "sourceIds": [
        "fc4",
        "notes4"
      ]
    },
    {
      "id": "mutual-benefit",
      "label": "寻找共同利益",
      "group": "h4",
      "parent": "h4",
      "summary": "不急于计算谁让了多少步，先理解各方怎样才会认为合作有价值。",
      "example": "你希望减少会议，对方希望及时获知进度，于是一起试用简短周报。",
      "prompt": "有哪些安排可以同时照顾彼此的需要？",
      "sourceIds": [
        "fc4"
      ]
    },
    {
      "id": "abundance",
      "label": "充足心态",
      "group": "h4",
      "parent": "h4",
      "summary": "把成功理解为可以共同创造的空间，而不总把别人的收获视为自己的损失。",
      "example": "团队成员提出好点子，你邀请他一起完善，而不担心功劳被抢走。",
      "prompt": "我是否过早把问题理解成只能有一个赢家？",
      "sourceIds": [
        "fc4",
        "notes4"
      ]
    },
    {
      "id": "integrity",
      "label": "诚信",
      "group": "h4",
      "parent": "h4",
      "summary": "说明自己的真实能力和限制，让承诺、原则与行为尽量一致，形成合作的可信基础。",
      "example": "你不确定能否赶上日期，于是给出真实范围和下一次确认时间。",
      "prompt": "我的表达是否让对方形成了不可靠的预期？",
      "sourceIds": [
        "notes4",
        "notes3"
      ]
    },
    {
      "id": "courage",
      "label": "表达自己的需要",
      "group": "h4",
      "parent": "mature-balance",
      "summary": "双赢也需要清楚表达自身关切，避免把沉默或不断退让当作合作。",
      "example": "你愿意帮忙，同时明确自己只能承担资料整理，无法兼顾全部协调。",
      "prompt": "我有哪些需要尚未清楚说出来？",
      "sourceIds": [
        "fc4"
      ]
    },
    {
      "id": "consideration",
      "label": "认真考虑他人",
      "group": "h4",
      "parent": "mature-balance",
      "summary": "把对方的处境和关切纳入决策，理解其需要，同时保留自己的判断与边界。",
      "example": "对方迟迟不确认安排，你先问是否还有资源或时间上的难处。",
      "prompt": "有什么是我还没有了解的现实限制？",
      "sourceIds": [
        "fc4"
      ]
    },
    {
      "id": "mature-balance",
      "label": "勇气与体谅的平衡",
      "group": "h4",
      "parent": "h4",
      "summary": "成熟的协商既能表达自己，也能照顾别人；任一侧被长期忽略都需要重新调整。",
      "example": "你提出不能接受的安排后，也邀请对方共同寻找可以满足目标的替代方式。",
      "prompt": "我现在更需要增加清楚表达，还是增加倾听？",
      "sourceIds": [
        "fc4"
      ]
    },
    {
      "id": "win-win-agreement",
      "label": "形成双赢约定",
      "group": "h4",
      "parent": "h4",
      "summary": "把共同期待写成明确约定，包括结果、支持、边界和检查方式，减少模糊承诺。",
      "example": "共同创作前，你们确认成果归属、时间安排和意见不一致时怎样处理。",
      "prompt": "这份约定是否让双方都知道自己答应了什么？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "supportive-systems",
      "label": "让制度支持合作",
      "group": "h4",
      "parent": "h4",
      "summary": "检查评价、奖励和信息安排是否支持共同目标，避免口头要求合作却奖励彼此竞争。",
      "example": "团队希望共享资料，却只表扬个人速度，于是重新讨论认可贡献的方式。",
      "prompt": "当前规则是在鼓励合作，还是制造竞争？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "no-deal",
      "label": "允许好聚好散",
      "group": "h4",
      "parent": "h4",
      "summary": "如果找不到彼此能够接受的方案，可以暂停或放弃这次合作，保护长期关系与边界。",
      "example": "双方对投入和期限始终无法达成一致，于是友好结束这次尝试。",
      "prompt": "不合作是否比勉强答应更尊重彼此？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "trust-deposits",
      "label": "情感账户与信任",
      "group": "h4",
      "parent": "h4",
      "summary": "信任通过理解、守信、清楚期待和真诚修复逐渐积累；它不是交换好意的计分表。",
      "example": "你及时解释一次失约并落实补救，之后用持续行动重新建立可靠感。",
      "prompt": "对这个人来说，什么行动才真正有帮助？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "h5",
      "label": "知彼解己",
      "group": "h5",
      "parent": "book",
      "summary": "先充分理解对方，再清楚表达自己；倾听与表达相互支持，而非一方永久让位。",
      "example": "面对分歧，你先复述对方担心的风险，确认后再解释自己的考虑。",
      "prompt": "对方会同意我已经理解他的主要关切吗？",
      "sourceIds": [
        "fc5",
        "notes3"
      ]
    },
    {
      "id": "empathic-listening",
      "label": "以理解为目的倾听",
      "group": "h5",
      "parent": "h5",
      "summary": "倾听时暂缓准备反驳或建议，努力理解对方的视角、意思和感受。",
      "example": "朋友说最近很累，你先听具体发生了什么，而不是马上推荐方法。",
      "prompt": "我是在理解对方，还是等待轮到自己说？",
      "sourceIds": [
        "fc5"
      ]
    },
    {
      "id": "check-understanding",
      "label": "复述与核对",
      "group": "h5",
      "parent": "empathic-listening",
      "summary": "用自己的话说明你听到的重点，并给对方纠正空间，避免把猜测当作理解。",
      "example": "你说“我听到你最担心的是时间不够，我理解得对吗？”",
      "prompt": "我可以怎样请对方纠正我的理解？",
      "sourceIds": [
        "fc5",
        "notes4"
      ]
    },
    {
      "id": "name-feelings",
      "label": "留意感受与意义",
      "group": "h5",
      "parent": "empathic-listening",
      "summary": "除了事情经过，也留意它对对方意味着什么；感受需要核对，不能替别人断定。",
      "example": "同事讲了一次被忽视的经历，你询问他更在意的是结果还是参与感。",
      "prompt": "这个经历对他来说，最重要的部分是什么？",
      "sourceIds": [
        "fc5"
      ]
    },
    {
      "id": "autobiographical",
      "label": "觉察自传式回应",
      "group": "h5",
      "parent": "h5",
      "summary": "只通过自己的经历解释他人，可能错过其独特处境；经验可以分享，但不应覆盖对方。",
      "example": "你想说“我以前也这样”，停下来后先问两人的具体条件是否相同。",
      "prompt": "我是否把别人的故事改成了自己的故事？",
      "sourceIds": [
        "fc5",
        "notes4"
      ]
    },
    {
      "id": "judging",
      "label": "暂缓价值判断",
      "group": "h5",
      "parent": "autobiographical",
      "summary": "在信息不足时先不急着评定对错，让事实与关切有机会被完整表达。",
      "example": "听到同伴想换工作，你先了解原因，而不是马上评价他是否坚持得够。",
      "prompt": "我现在的判断建立在足够信息上吗？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "probing",
      "label": "询问而非盘问",
      "group": "h5",
      "parent": "autobiographical",
      "summary": "提问要帮助对方表达，而不是只满足自己的好奇或把话题引到预设结论。",
      "example": "对方不愿谈某个细节时，你尊重暂停，并问他愿意从哪里说起。",
      "prompt": "我的问题在帮助理解，还是在推动我想听的答案？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "advising",
      "label": "给建议前先确认",
      "group": "h5",
      "parent": "autobiographical",
      "summary": "建议应建立在了解问题与对方意愿之后；有时对方更需要被听见或共同澄清。",
      "example": "朋友抱怨安排混乱，你先问他想有人听听，还是一起找办法。",
      "prompt": "现在最需要的是倾听、分析还是建议？",
      "sourceIds": [
        "notes4",
        "mapnotes1"
      ]
    },
    {
      "id": "interpreting",
      "label": "不替对方推断动机",
      "group": "h5",
      "parent": "autobiographical",
      "summary": "避免仅凭自身经验解释他人的动机；把推测作为待核对的问题而不是结论。",
      "example": "回复很短不一定表示不满，你先确认对方是否正在忙或信息已足够。",
      "prompt": "我能把这个推断改成一个开放问题吗？",
      "sourceIds": [
        "fc5",
        "notes4"
      ]
    },
    {
      "id": "clear-expression",
      "label": "让自己也被理解",
      "group": "h5",
      "parent": "h5",
      "summary": "理解之后，清楚说明自己的事实、理由、感受与请求，让对方有机会回应。",
      "example": "确认同伴的担忧后，你说明自己的时限，并提出一个可讨论的安排。",
      "prompt": "我希望对方理解什么，又希望一起决定什么？",
      "sourceIds": [
        "fc5"
      ]
    },
    {
      "id": "h6",
      "label": "统合综效",
      "group": "h6",
      "parent": "book",
      "summary": "让不同经验和能力进入共同探索，创造比现有各方方案更合适的新选择。",
      "example": "两人对活动形式意见不同，先列共同目标，再设计一个新的组合方案。",
      "prompt": "差异里有没有我们单独想不到的信息？",
      "sourceIds": [
        "fc6",
        "notes3"
      ]
    },
    {
      "id": "value-differences",
      "label": "重视差异",
      "group": "h6",
      "parent": "h6",
      "summary": "把不同视角当作可能补足认知的信息，而不是只容忍它存在或急于消除。",
      "example": "有人关注体验，有人关注成本，你们把两类观察一起用于评估方案。",
      "prompt": "这个不同意见看见了我忽略的什么？",
      "sourceIds": [
        "fc6"
      ]
    },
    {
      "id": "third-alternative",
      "label": "寻找第三种选择",
      "group": "h6",
      "parent": "h6",
      "summary": "共同创造一个超出原有二选一的新方案；它不只是机械折中，也不保证每次都能找到。",
      "example": "关于线下还是线上活动的争论，转为先线上准备、再小范围线下实践。",
      "prompt": "如果暂时放下各自方案，还能怎样满足需要？",
      "sourceIds": [
        "fc6",
        "notes4"
      ]
    },
    {
      "id": "shared-goal",
      "label": "明确共同目标",
      "group": "h6",
      "parent": "h6",
      "summary": "先确定各方共同希望实现的结果和判断标准，再讨论具体做法与取舍。",
      "example": "改版讨论先确定要让新读者更容易找到入口，再比较不同布局。",
      "prompt": "我们共同想改善的结果究竟是什么？",
      "sourceIds": [
        "fc6"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "needs-behind-positions",
      "label": "从立场走向需要",
      "group": "h6",
      "parent": "h6",
      "summary": "区分对方坚持的方案与其背后想保护的东西，为重新组合方案找到空间。",
      "example": "坚持每天开会的人也许需要进度可见，而不是会议本身。",
      "prompt": "这个要求背后的实际需要是什么？",
      "sourceIds": [
        "notes4",
        "fc4"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "open-information",
      "label": "让新信息进入讨论",
      "group": "h6",
      "parent": "h6",
      "summary": "邀请不同经验和顾虑进入共同问题空间，降低只寻找支持自身观点证据的倾向。",
      "example": "方案评审时，你特意邀请平时较少发言的人提出可能漏掉的情况。",
      "prompt": "还有谁的观察能改变我们对问题的理解？",
      "sourceIds": [
        "fc6",
        "notes4"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "combine-strengths",
      "label": "组合不同长处",
      "group": "h6",
      "parent": "h6",
      "summary": "识别各方擅长的部分，使能力形成互补；合作成果仍需要明确协调与责任。",
      "example": "一人擅长发现问题，一人擅长组织表达，两人分别负责再交叉检查。",
      "prompt": "怎样分工能让不同长处一起发挥作用？",
      "sourceIds": [
        "fc6",
        "notes3"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "co-create-options",
      "label": "共同生成方案",
      "group": "h6",
      "parent": "h6",
      "summary": "先允许多个思路被提出和组合，再依据共同目标筛选，减少过早否定可能性。",
      "example": "你们先列三种活动结构，并尝试合并其中各自有效的部分。",
      "prompt": "有没有两个想法可以组合成更好的一个？",
      "sourceIds": [
        "fc6"
      ]
    },
    {
      "id": "trial-solution",
      "label": "用小尝试检验方案",
      "group": "h6",
      "parent": "co-create-options",
      "summary": "把新想法做成可观察的小范围尝试，用结果帮助各方继续改进，而不只停留在争论。",
      "example": "对新分工没有把握，就先试行一周，再看哪些环节需要调整。",
      "prompt": "我们怎样低成本地验证这个新选择？",
      "sourceIds": [
        "fc6"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "safe-dialogue",
      "label": "建立可讨论的空间",
      "group": "h6",
      "parent": "h6",
      "summary": "合作需要人们能够表达差异与疑虑；尊重和信任有助于减少防御、增加真实信息。",
      "example": "讨论中有人提出异议，主持人先感谢其补充，再邀请说明依据。",
      "prompt": "我们是否让不同意见有安全的表达位置？",
      "sourceIds": [
        "fc4",
        "fc5",
        "notes4"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "h7",
      "label": "不断更新",
      "group": "h7",
      "parent": "book",
      "summary": "持续维护身体、心智、关系和价值感，为其余习惯提供支持，不把恢复变成额外竞赛。",
      "example": "你减少一项无意义的消耗，留出恢复时间，再观察一周后的状态。",
      "prompt": "我现在最需要照顾的是哪个方面？",
      "sourceIds": [
        "fc7",
        "notes3"
      ]
    },
    {
      "id": "physical-renewal",
      "label": "身体更新",
      "group": "h7",
      "parent": "h7",
      "summary": "关注休息、活动和日常照顾，为行动保留基本条件；具体安排应符合个人现实。",
      "example": "久坐工作之后，你安排一段适合自己的轻松活动，而不是再增加考核任务。",
      "prompt": "哪种日常安排更有助于我的身体恢复？",
      "sourceIds": [
        "fc7"
      ]
    },
    {
      "id": "mental-renewal",
      "label": "心智更新",
      "group": "h7",
      "parent": "h7",
      "summary": "通过学习、思考与表达继续发展理解能力，把获得信息与消化信息区分开来。",
      "example": "看完一篇文章，你用自己的话写三句理解，再查一个仍没想通的问题。",
      "prompt": "我最近学到的东西，有没有真正处理过？",
      "sourceIds": [
        "fc7",
        "notes4"
      ]
    },
    {
      "id": "social-renewal",
      "label": "关系与情感更新",
      "group": "h7",
      "parent": "h7",
      "summary": "为重要关系投入真实的理解、支持与相处，让合作所需的信任得到维护。",
      "example": "忙碌一周后，你与亲近的人留出一段不处理其他消息的交谈时间。",
      "prompt": "我想为哪段关系增加一点有质量的关注？",
      "sourceIds": [
        "fc7"
      ]
    },
    {
      "id": "spiritual-renewal",
      "label": "价值与精神更新",
      "group": "h7",
      "parent": "h7",
      "summary": "回到自己重视的价值和意义，检查生活方向；方式可以不同，不预设宗教立场。",
      "example": "你重新读自己的使命草稿，发现最近忙碌的事情偏离了真正重视的方向。",
      "prompt": "哪些事情能让我重新记起为什么而行动？",
      "sourceIds": [
        "fc7",
        "notes4"
      ]
    },
    {
      "id": "rest-rhythm",
      "label": "恢复的节奏",
      "group": "h7",
      "parent": "physical-renewal",
      "summary": "给恢复留下可持续的位置，不把它仅当作做完所有工作之后才能获得的奖励。",
      "example": "一段密集交付之后，你主动安排缓冲，而不继续接入同样强度的任务。",
      "prompt": "我能减少什么，给恢复腾出空间？",
      "sourceIds": [
        "fc7"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "learning-practice",
      "label": "学习、尝试与回顾",
      "group": "h7",
      "parent": "mental-renewal",
      "summary": "把阅读得到的理解放进一次小实践，再通过观察修正认识，让学习形成循环。",
      "example": "学到核对理解后，你在一次沟通中尝试，并记录对话有什么不同。",
      "prompt": "哪个概念值得先试一次，再决定怎样调整？",
      "sourceIds": [
        "fc7",
        "notes4"
      ],
      "contentKind": "本站实践延伸"
    },
    {
      "id": "renewal-balance",
      "label": "四个方面相互支持",
      "group": "h7",
      "parent": "h7",
      "summary": "留意各个方面怎样影响彼此；平衡是持续调整，不是每天给每个方面平均打卡。",
      "example": "你发现关系冲突正在消耗注意力，于是先处理沟通，而不只加大学习量。",
      "prompt": "哪个被忽略的方面正在影响其他部分？",
      "sourceIds": [
        "fc7",
        "notes3"
      ]
    },
    {
      "id": "growth-spiral",
      "label": "持续更新的循环",
      "group": "h7",
      "parent": "h7",
      "summary": "在实践中继续学习和修正，让能力逐步增长；成长允许放慢、缩小和重新开始。",
      "example": "一次计划没有完成，你复盘原因，把下一次行动缩小到现实可行的程度。",
      "prompt": "下一轮，我要保留什么、调整什么？",
      "sourceIds": [
        "fc7"
      ]
    },
    {
      "id": "dependence",
      "label": "依赖：需要他人的支持",
      "parent": "maturity",
      "group": "foundation",
      "summary": "成长框架从依赖走向独立，再走向互赖。承认需要支持，是看清当前处境的一步；这不是给人的价值分等级。",
      "example": "刚开始新工作时需要指导，熟悉后逐步承担判断，再与同事互补合作。",
      "prompt": "这件事上，我需要怎样的支持，又能主动承担哪一步？",
      "sourceIds": [
        "maturity2026"
      ]
    }
  ],
  "links": [
    {
      "source": "principles",
      "target": "personal-mission",
      "label": "成为取舍依据",
      "reason": "使命宣言把抽象原则变成可以在具体选择中回看的语言。"
    },
    {
      "source": "perspectives",
      "target": "value-differences",
      "label": "借差异拓宽视角",
      "reason": "不同意见提醒我们检查自己的解释，可能揭示原先遗漏的信息。"
    },
    {
      "source": "habit-skill",
      "target": "learning-practice",
      "label": "通过尝试发展",
      "reason": "知道一个方法之后，实际练习和回顾才能帮助发现自己还不会的部分。"
    },
    {
      "source": "pc-balance",
      "target": "h7",
      "label": "维护持续行动的条件",
      "reason": "更新照顾身体、学习和关系，回应产能不能被长期消耗的提醒。"
    },
    {
      "source": "interdependence",
      "target": "mutual-benefit",
      "label": "需要彼此受益的安排",
      "reason": "有选择的合作需要理解各方的关切，而不是只寻找个人最大收益。"
    },
    {
      "source": "influence-circle",
      "target": "say-no",
      "label": "把注意力转为边界",
      "reason": "看清自己能决定的部分，有助于清楚协商任务范围与回应时间。"
    },
    {
      "source": "independent-will",
      "target": "reserve-time",
      "label": "让选择进入行动",
      "reason": "保护重要时间需要实际执行取舍，而不只是认同它很重要。"
    },
    {
      "source": "keep-promises",
      "target": "trust-deposits",
      "label": "以行动积累信任",
      "reason": "守信或及时重新协商，可以让合作中的期待更可靠。"
    },
    {
      "source": "learn-errors",
      "target": "growth-spiral",
      "label": "把失误带入下一轮",
      "reason": "修复具体错误并改进做法，使一次受挫成为继续学习的材料。"
    },
    {
      "source": "physical-creation",
      "target": "h3",
      "label": "由构想到安排",
      "reason": "已经澄清的方向需要通过优先次序与具体行动落实。"
    },
    {
      "source": "personal-mission",
      "target": "weekly-plan",
      "label": "连接方向与这一周",
      "reason": "周计划可以检验当前时间安排是否服务自己认可的长期方向。"
    },
    {
      "source": "role-goals",
      "target": "role-balance",
      "label": "检查投入是否失衡",
      "reason": "看见不同角色的目标，有助于发现哪些重要责任长期没有得到时间。"
    },
    {
      "source": "success-criteria",
      "target": "shared-goal",
      "label": "对齐判断标准",
      "reason": "合作前共同定义有效结果，可以减少各自按不同标准争论方案。"
    },
    {
      "source": "important-not-urgent",
      "target": "mental-renewal",
      "label": "主动为学习留位置",
      "reason": "学习往往不会立即催促，却会影响未来处理问题的能力。"
    },
    {
      "source": "important-not-urgent",
      "target": "social-renewal",
      "label": "把关系维护放进日常",
      "reason": "平时的理解与相处不一定紧迫，但持续忽略会削弱关系支持。"
    },
    {
      "source": "delegation-agreement",
      "target": "win-win-agreement",
      "label": "用清楚约定支持自主",
      "reason": "两者都需要对齐结果、边界和支持条件，减少彼此凭猜测行动。"
    },
    {
      "source": "courage",
      "target": "clear-expression",
      "label": "让自己也被听见",
      "reason": "清楚表达自己的关切，是双赢中保护自身需要的具体方式。"
    },
    {
      "source": "consideration",
      "target": "empathic-listening",
      "label": "让体谅获得真实信息",
      "reason": "倾听能够核对对方实际在意什么，避免仅凭想象替别人决定。"
    },
    {
      "source": "trust-deposits",
      "target": "safe-dialogue",
      "label": "降低表达差异的顾虑",
      "reason": "已有信任让人更愿意提出疑问和不同意见，为合作提供更多信息。"
    },
    {
      "source": "check-understanding",
      "target": "needs-behind-positions",
      "label": "从方案问到关切",
      "reason": "核对理解有助于区分一个人提出的做法与其背后希望保护的东西。"
    },
    {
      "source": "empathic-listening",
      "target": "third-alternative",
      "label": "为新选择打开空间",
      "reason": "理解不同需求之后，才更容易创造超出原先各自立场的方案。"
    },
    {
      "source": "spiritual-renewal",
      "target": "values-center",
      "label": "定期回看方向",
      "reason": "更新也包括检查近期选择是否仍然符合自己真正重视的价值。"
    }
  ],
  "sources": [
    {
      "id": "mapnotes1",
      "type": "公开思维导图",
      "title": "ZhiMap · 高效人士的七个习惯",
      "url": "https://zhimap.com/mhtml/a27e6707e8964ec0904e1d4d6a3b75ca",
      "use": "交叉核对概念层次、选择能力、使命、授权与沟通主题；不复制原图。"
    },
    {
      "id": "mapnotes2",
      "type": "中文导图文章",
      "title": "MindManager 中文网站 · 七个习惯导图笔记",
      "url": "https://mindmanager.mairuan.com/shiyongjiqiao/mm-swdtdsbja.html",
      "use": "对照四项选择能力、两次创造和层次组织；不复制文章中的图形。"
    },
    {
      "id": "maturity2026",
      "type": "官方公开资料",
      "title": "FranklinCovey · 七个习惯简明指南",
      "url": "https://www.franklincovey.ie/wp-content/uploads/sites/10/2023/01/the-7-habits-a-brief-guide-MRK2057800_V1.0.6.2.pdf",
      "use": "核对依赖、独立、互赖的成长关系；例子与问题为本站原创。"
    }
  ]
};
window.STAR_MAP_DATA.sources.forEach(function(s){if(!window.READING_DATA.sources.some(function(x){return x.id===s.id;}))window.READING_DATA.sources.push(s);});
