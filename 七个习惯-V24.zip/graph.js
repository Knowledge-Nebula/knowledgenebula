(function(){
  'use strict';
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const palette={book:'#e1c98b',foundation:'#c4b891',h1:'#8fc4b0',h2:'#a6bce0',h3:'#d7bd8c',h4:'#b5bd8b',h5:'#8cc4cb',h6:'#b8a5cb',h7:'#ce9f8c'};
  let sessionView=null,hintSeen=false;
  const NS='http://www.w3.org/2000/svg';
  const svgEl=(name,attrs)=>{const el=document.createElementNS(NS,name);for(const [k,v] of Object.entries(attrs||{}))el.setAttribute(k,String(v));return el;};
  function mount(container,{initialId='book',onSelect=()=>{},motion=true}={}){
    const C=window.StarGraphCore;
    function createGraph(){const g=C.prepare(window.STAR_MAP_DATA);if(matchMedia('(max-width:800px)').matches)g.nodes.forEach(n=>{n.x*=.58;n.anchorX*=.58;});return g;}
    const graph=createGraph(),saved=sessionView;
    if(saved)for(const n of graph.nodes){const old=saved.nodes[n.id];if(old)Object.assign(n,old);}
    const legacy={f1:'foundation',f2:'foundation',f3:'book'};
    let selected=saved&&initialId==='book'?saved.selected:graph.byId.has(initialId)?initialId:legacy[initialId]||'book';
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    let mode='graph',group='all',depth=99,hops=1,cross=true,allLabels=false,spacing=1,paused=reduced.matches||!motion||document.body.classList.contains('still'),expanded=false,editing=false;
    if(saved){mode=saved.mode;group=saved.group;depth=saved.depth;hops=saved.hops;cross=saved.cross;allLabels=saved.allLabels;spacing=saved.spacing;paused=paused||saved.paused;}
    const trail=saved?[...saved.trail]:[],visited=new Set(saved?saved.visited:[selected]),inertBackground=[];
    let camera={x:0,y:0,k:1},width=800,height=640,active=null,hover=null,frame=0,alpha=0,dead=false,dirty=true,lastPointerClick=0;
    if(saved)camera={...saved.camera};
    let visibleIds=C.visible(graph,{group,depth}),currentLinks=[],nodeEls=new Map(),edgeEls=[],fitPending=true;
    const sourceById=new Map(window.READING_DATA.sources.map(s=>[s.id,s]));
    container.innerHTML=`<div class="star-workspace" aria-label="七个习惯知识星图工作区">
      <div class="star-toolbar"><div class="star-title"><span class="star-mark" aria-hidden="true">✧</span><div><strong>七个习惯 · 知识星图</strong><small>${graph.nodes.length} 个概念 / ${graph.groups.length} 个主题星群</small></div></div><div class="star-search-wrap"><span class="star-search-icon" aria-hidden="true">⌕</span><input id="star-search" type="search" placeholder="搜索概念，如：影响圈、倾听…" aria-label="搜索星图概念" aria-controls="star-search-results" aria-expanded="false" autocomplete="off"><div id="star-search-results" class="star-search-results" hidden></div><span id="star-search-status" class="star-sr-only" role="status"></span></div><button class="star-expand" data-star="expand" aria-pressed="false">⤢ 展开工作区</button></div>
      <div class="star-viewbar"><div class="star-tabs" aria-label="知识星图视图"><button data-star-view="graph" aria-pressed="true">全局星图</button><button data-star-view="directory" aria-pressed="false">知识框架</button></div><div class="star-detail-options"><label><span id="star-depth-label">展开层级</span><select id="star-depth" aria-label="展开层级"><option value="1">主题</option><option value="2">核心概念</option><option value="99" selected>全部细节</option></select><select id="star-hops" aria-label="局部联系深度" hidden><option value="1">一层联系</option><option value="2">两层联系</option></select></label><label><input id="star-cross" type="checkbox" checked>跨习惯联系</label><label><input id="star-labels" type="checkbox">全部标签</label></div></div>
      <div class="star-layout"><div class="star-visual"><div class="star-stage"><div class="star-canvas-label">THE 7 HABITS / CONNECTED THINKING<strong id="star-scope-title">从一个概念，走向另一种理解。</strong><p id="star-canvas-note">拖动光点，观察联系如何跟随。</p></div><svg id="star-svg" role="group" tabindex="0" aria-label="可交互知识星图：点击节点阅读，方向键平移，加减键缩放" aria-describedby="star-instructions"><g id="star-world"><g id="star-edges"></g><g id="star-nodes"></g></g></svg><div class="star-controls"><button data-star="zoom-in" aria-label="放大星图">+</button><span class="star-zoom" aria-live="off">100%</span><button data-star="zoom-out" aria-label="缩小星图">−</button><button data-star="fit" aria-label="适配当前全图" title="适配当前全图">⌖</button><button data-star="pause" aria-label="${paused?'继续节点运动':'暂停节点运动'}" aria-pressed="${paused}" title="暂停或继续节点运动">${paused?'▷':'Ⅱ'}</button><button data-star="reset" aria-label="重置节点位置" title="重置节点位置">↺</button></div><div class="star-minimap" aria-hidden="true"><svg viewBox="0 0 110 80"></svg></div><button class="star-mobile-edit" data-star="touch" aria-pressed="false">启用拖拽</button></div><div class="star-legend"><span><i></i>概念层级</span><span><i class="dashed"></i>跨主题联系 · 本站整理</span><span class="star-live-count" role="status"></span></div></div><div class="star-directory" hidden></div><aside class="star-sidebar" id="star-detail" tabindex="-1" aria-label="所选概念解释"></aside></div>
      <div class="star-footbar"><div class="star-clusters" aria-label="主题星群筛选"><button data-star-group="all" aria-pressed="true">全部星群</button>${graph.groups.map(g=>`<button data-star-group="${g.id}" style="--group-color:${palette[g.id]}" aria-pressed="false"><i></i>${g.id==='foundation'?'前言：观念与原则':/^h[1-7]$/.test(g.id)?'('+['I','II','III','IV','V','VI','VII'][Number(g.id[1])-1]+') '+esc(g.label):esc(g.label)}</button>`).join('')}</div><label class="star-spacing">疏密<input type="range" min="75" max="145" value="100" id="star-spacing" aria-label="节点间距"></label></div>
    </div><div class="star-help" id="star-instructions"><p>点击阅读 · 拖动调整 · Shift + 滚轮缩放</p><details><summary>使用说明</summary><p>手机默认正常滚动；点“启用拖拽”后可移动节点。放大可见更多标签。搜索与知识框架覆盖全部概念。键盘可用 + / − 缩放、方向键平移、0 适配全图；节点按 Enter 阅读。虚线联系是本站的教学整理，点击节点后可读具体原因。离开再返回会保留本次浏览的地图位置，刷新恢复初始布局。参考 <a href="https://obsidian.md/help/plugins/graph" target="_blank" rel="noopener noreferrer">Obsidian Graph view</a> 的交互方式，图谱内容与视觉为本站重新编排。</p></details></div>`;
    const $=s=>container.querySelector(s),work=$('.star-workspace'),svg=$('#star-svg'),stage=$('.star-stage'),world=$('#star-world'),side=$('.star-sidebar'),mini=$('.star-minimap svg'),directory=$('.star-directory');
    work.prepend($('.star-visual'));$('.star-legend').insertBefore($('.star-help'),$('.star-live-count'));
    const abort=new AbortController(),signal=abort.signal;
    stage.append(directory);directory.classList.add('mindmap-layer');directory.hidden=false;directory.inert=true;
    const tree=window.KnowledgeTree.mount(directory,{nodes:graph.nodes,signal,onSelect:id=>select(id,{fromGraph:true,toggle:true})});
    const switcher=document.createElement('div');switcher.className='map-view-switch';switcher.setAttribute('role','group');switcher.setAttribute('aria-label','切换知识视图');switcher.innerHTML='<span class="view-indicator" aria-hidden="true"></span><button data-star-view="graph" aria-pressed="true">星图</button><button data-star-view="directory" aria-pressed="false">框架</button>';stage.append(switcher);
    let transitionTimer=0,graphDepth=saved?.graphDepth||99,treeDepth=saved?.treeDepth||99;
    const entryHint=document.createElement('div');entryHint.className='star-entry-hint';entryHint.setAttribute('aria-hidden','true');entryHint.innerHTML='<span>先点「七个习惯」</span><b>↓</b>';if(!hintSeen){stage.append(entryHint);hintSeen=true;}const hintTimer=setTimeout(()=>entryHint.remove(),3000);stage.addEventListener('pointerdown',()=>entryHint.remove(),{once:true,signal});
    $('.star-tabs').remove();
    const listen=(el,type,fn,opts={})=>el.addEventListener(type,fn,{...opts,signal});
    const color=n=>palette[n.group]||palette.book;
    function notifySelection(n){onSelect(n.id,/^h[1-7]$/.test(n.group)?n.group:null);}
    function focusVisual(){if(mode==='directory')tree.focus(selected);else (nodeEls.get(selected)||svg).focus({preventScroll:true});}
    side.inert=true;side.setAttribute('aria-hidden','true');
    function openDetail(){side.inert=false;side.setAttribute('aria-hidden','false');side.classList.add('is-open');}
    function closeDetail(){side.classList.remove('is-open');side.inert=true;side.setAttribute('aria-hidden','true');hover=null;dirty=true;wake(.01);focusVisual();}
    function focusDetail(){const title=$('#star-detail-title');if(title)title.focus({preventScroll:true});}
    function closeSearch(){const results=$('#star-search-results');results.hidden=true;$('#star-search').setAttribute('aria-expanded','false');}
    function isolateWorkspace(value){
      if(value){let branch=work;while(branch.parentElement){const parent=branch.parentElement;for(const sibling of parent.children){if(sibling!==branch){inertBackground.push([sibling,sibling.inert]);sibling.inert=true;}}if(parent===document.body)break;branch=parent;}}
      else{for(const [element,wasInert] of inertBackground)element.inert=wasInert;inertBackground.length=0;}
    }
    function syncMotion(){
      const blocked=reduced.matches||!motion||document.body.classList.contains('still');
      if(blocked)paused=true;
      const b=$('[data-star="pause"]');b.disabled=blocked;b.setAttribute('aria-pressed',String(paused));b.setAttribute('aria-label',blocked?'已遵循减少动态设置':paused?'继续节点运动':'暂停节点运动');b.title=blocked?'已遵循减少动态设置':paused?'继续节点运动':'暂停节点运动';b.textContent=paused?'▷':'Ⅱ';
    }
    function connections(id){return graph.links.filter(l=>l.source===id||l.target===id);}
    function other(l,id){return graph.byId.get(l.source===id?l.target:l.source);}
    const bookQuestions=[['h3','忙了一天，重要的事没做'],['h5','说了很多，还是没听懂'],['h1','总被别人的反应牵着走'],['h2','一直在往前赶，却不清楚要去哪'],['h4','各有各的要求，怎样让双方都愿意'],['h6','意见不一样，就只能选一边吗'],['h7','越忙越疲惫，怎么把精力找回来']];
    let questionOffset=0;
    function questionOptions(){return [bookQuestions[questionOffset],bookQuestions[(questionOffset+1)%bookQuestions.length]].map(([id,text])=>'<button data-star-select="'+id+'">'+esc(text)+'<span aria-hidden="true">↗</span></button>').join('')+'<button data-star="framework">先看整本书的思路<span aria-hidden="true">→</span></button>';}
    function bookPanel(){return '<nav class="star-trail"><button data-star="close-detail" aria-label="关闭阅读面板">关闭 ×</button><button data-star="locate">返回图中</button></nav><h2 id="star-detail-title" tabindex="-1">不知道从哪开始？</h2><a class="interest-quiz-door" href="#coach"><span class="interest-compass" aria-hidden="true">✧</span><span><strong>五分钟，找到想读的方向</strong><small>从自己的事、与人相处或恢复余力开始。</small></span><span aria-hidden="true">→</span></a><p class="interest-intro">或者，直接选择下面的方向。</p><nav class="interest-grid" aria-label="选择阅读方向">'+[['all','全览','整本书的框架'],['h1','减少内耗','积极主动'],['h2','明确方向','以终为始'],['h3','把时间用对','要事第一'],['h4','找到双赢','双赢思维'],['h5','听懂彼此','知彼解己'],['h6','共创新解','统合综效'],['h7','恢复与成长','不断更新']].map(([id,title,sub])=>'<button '+(id==='all'?'data-star="framework"':'data-star-select="'+id+'"')+'><strong>'+title+'</strong><small>'+sub+'</small></button>').join('')+'</nav><div class="book-panel-bottom"><div class="drawer-section-label"><span>拓展与训练</span></div><nav class="drawer-doors" aria-label="其他学习入口">'+[['practice','生活练习'],['explore','拓展阅读']].map(([id,title])=>'<a href="#'+id+'"><span class="drawer-door-art">'+window.ReadingExperience.compactVisual(id)+'</span><span>'+title+'</span></a>').join('')+'</nav></div>';}
    function renderDetail(){
      side.classList.toggle('is-book',selected==='book');if(selected==='book'){side.innerHTML=bookPanel();side.scrollTop=0;return;}
      const n=graph.byId.get(selected),parent=graph.byId.get(n.parent),g=graph.byId.get(n.group),rels=connections(n.id),bridges=rels.filter(l=>l.type==='connection');
      const children=rels.filter(l=>l.type==='hierarchy'&&l.source===n.id);
      const h=/^h[1-7]$/.test(n.group)?n.group:null;
      side.innerHTML=`<nav class="star-trail"><button data-star="close-detail" aria-label="关闭阅读面板">关闭 ×</button><button data-star="previous" ${trail.length?'':'disabled'}>← 上一概念</button><button data-star="locate">返回图中</button></nav><h2 id="star-detail-title" tabindex="-1">${esc(n.label)}</h2>${n.contentKind?`<small class="concept-kind">${esc(n.contentKind)}</small>`:""}<p class="star-summary">${esc(n.summary)}</p>${n.id==='book'?`<div class="map-start"><p>先选一个与你有关的问题。</p><button data-star-select="h3">忙了一天，重要的事没做</button><button data-star-select="h5">说了很多，还是没听懂</button><button data-star="framework">先看整本书的思路 →</button></div>`:`<div class="star-reflection">${esc(n.prompt)}</div><div class="star-sidebar-actions"><a class="button small" href="#insight/${h||'h1'}">读懂这个习惯 ↗</a></div><details class="detail-fold"><summary>看一个生活例子</summary><p>${esc(n.example)}</p></details>`}<details class="detail-fold"><summary>相关概念与联系</summary><div class="star-relation-list">${bridges.map(l=>`<button data-star-select="${other(l,n.id).id}"><strong>${esc(other(l,n.id).label)}</strong><small>${esc(l.reason)}</small></button>`).join('')}${children.map(l=>`<button data-star-select="${l.target}">${esc(l.b.label)}</button>`).join('')}</div></details>`;
      side.scrollTop=0;
    }
    function renderDirectory(){const counts=tree.render({depth,group});tree.highlight(selected);$('.star-live-count').textContent=counts.nodes+' 个概念 · '+counts.links+' 条分支';}
    function updateControls(){
      container.querySelectorAll('[data-star-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.starView===mode)));
      container.querySelectorAll('[data-star-group]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.starGroup===group)));
      $('#star-depth').hidden=mode==='local';$('#star-hops').hidden=mode!=='local';$('#star-depth-label').textContent=mode==='local'?'关系深度':'展开层级';
      $('#star-scope-title').textContent=mode==='local'?graph.byId.get(selected).label+' · 局部联系':group==='all'?'从一个概念，走向另一种理解。':graph.byId.get(group).label+' · 主题星群';
      $('#star-canvas-note').textContent=mode==='local'?'沿着连线，读懂概念之间的关系。':'拖动光点，观察联系如何跟随。';
      $('.star-live-count').textContent=`${visibleIds.size} / ${graph.nodes.length} 节点 · ${currentLinks.length} 条联系`;
      $('.star-visual').hidden=false;directory.hidden=false;directory.inert=mode!=='directory';svg.inert=mode==='directory';svg.setAttribute('tabindex',mode==='directory'?'-1':'0');svg.querySelectorAll('[data-star-node]').forEach(n=>n.setAttribute('tabindex',mode==='directory'?'-1':'0'));svg.setAttribute('aria-hidden',String(mode==='directory'));directory.setAttribute('aria-hidden',String(mode!=='directory'));stage.classList.toggle('tree-active',mode==='directory');switcher.dataset.mode=mode;
      $('.star-detail-options').hidden=false;$('.star-detail-options label:has(#star-cross)').hidden=mode==='directory';$('.star-detail-options label:has(#star-labels)').hidden=mode==='directory';
    }
    function rebuild({fit=true}={}){
      visibleIds=C.visible(graph,{group,depth,local:mode==='local',selected,hops,cross});
      currentLinks=graph.links.filter(l=>visibleIds.has(l.source)&&visibleIds.has(l.target)&&(cross||l.type!=='connection'));
      if(mode==='directory'){updateControls();renderDirectory();return;}
      nodeEls.clear();edgeEls=[];$('#star-edges').replaceChildren();$('#star-nodes').replaceChildren();
      for(const l of currentLinks){const line=svgEl('line',{class:'star-edge'+(l.type==='connection'?' cross':'')});$('#star-edges').appendChild(line);edgeEls.push({line,link:l});}
      for(const n of graph.nodes.filter(n=>visibleIds.has(n.id)).sort((a,b)=>b.depth-a.depth)){
        const el=svgEl('g',{'data-star-node':n.id,role:'button',tabindex:'0','aria-label':n.label,'aria-pressed':String(n.id===selected),class:'star-node'+(n.depth<2?' major':'')+(n.id==='book'?' root':''),style:'--node-color:'+color(n)});
        el.append(svgEl('circle',{class:'node-hit'}),svgEl('circle',{class:'node-glow'}),svgEl('circle',{class:'node-ring'}),svgEl('circle',{class:'node-dot'}),svgEl('circle',{class:'node-pin'}));
        const label=svgEl('text',{'text-anchor':'start'});label.textContent=n.id==='book'?'七个习惯':n.id==='foundation'?'前言：观念与原则':n.label;el.append(label);if(/^h[1-7]$/.test(n.id)){const number=svgEl('text',{class:'node-number'});number.textContent='('+['I','II','III','IV','V','VI','VII'][Number(n.id[1])-1]+')';el.append(number);}$('#star-nodes').append(el);nodeEls.set(n.id,el);
      }
      updateControls();if(mode==='directory')renderDirectory();fitPending=fit;
      if(fit){for(let i=0;i<65;i++)C.step(graph,{alpha:.65,spacing,visibleIds});if(matchMedia('(max-width:800px)').matches){const positions={book:[0,0],foundation:[155,-510],h7:[-155,-410],h1:[155,-270],h6:[-155,-160],h2:[155,120],h5:[-155,260],h3:[155,420],h4:[-155,560]},orig=new Map(graph.nodes.map(n=>[n.id,{x:n.x,y:n.y}]));graph.nodes.forEach(n=>{const base=positions[n.group]||positions.book,old=orig.get(n.group)||orig.get('book');n.x=base[0]+(n.x-old.x)*.38;n.y=base[1]+(n.y-old.y)*.65;n.anchorX=n.x;n.anchorY=n.y;});}}
      dirty=true;wake(.65);if(paused){fitPending=false;if(fit)fitGraph();draw();}
    }
    function setMode(next){if(next===mode)return;clearTimeout(transitionTimer);const animate=!reduced.matches&&motion&&!document.body.classList.contains('still');stage.classList.toggle('view-changing',animate);if(mode==='directory')treeDepth=depth;else graphDepth=depth;mode=next;depth=mode==='directory'?treeDepth:graphDepth;$('#star-depth').value=String(depth);if(side.classList.contains('is-open'))closeDetail();updateControls();if(mode==='directory')renderDirectory();else{rebuild({fit:false});dirty=true;wake(.01);}if(animate)transitionTimer=setTimeout(()=>stage.classList.remove('view-changing'),360);else stage.classList.remove('view-changing');}
    function select(id,{locate=false,fromGraph=false,track=true,toggle=false}={}){
      if(!graph.byId.has(id))return;if(toggle&&id===selected&&side.classList.contains('is-open')){closeDetail();return;}
      const restoreDetail=side.contains(document.activeElement)||directory.contains(document.activeElement)||$('.star-search-wrap').contains(document.activeElement);
      if(track&&id!==selected){trail.push(selected);if(trail.length>30)trail.shift();}
      selected=id;visited.add(id);hover=null;notifySelection(graph.byId.get(id));renderDetail();
      if(mode==='local')rebuild();else if(!visibleIds.has(id)&&mode!=='directory'){group='all';depth=99;$('#star-depth').value='99';rebuild();}
      if(mode==='directory')tree.highlight(selected);
      if(locate){if(mode==='directory')mode='graph';rebuild({fit:false});centerNode(graph.byId.get(id));}
      dirty=true;wake(.03);
      openDetail();if(restoreDetail||fromGraph)focusDetail();
      
    }
    function viewSize(){const b=stage.getBoundingClientRect();if(!b.width||!b.height)return;width=b.width;height=b.height;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);}
    function bounds(){const ns=graph.nodes.filter(n=>visibleIds.has(n.id));return {minX:Math.min(...ns.map(n=>n.x))-90,maxX:Math.max(...ns.map(n=>n.x))+120,minY:Math.min(...ns.map(n=>n.y))-100,maxY:Math.max(...ns.map(n=>n.y))+85};}
    function fitGraph(){viewSize();const ns=graph.nodes.filter(n=>visibleIds.has(n.id));let x0=Math.min(...ns.map(n=>n.x)),x1=Math.max(...ns.map(n=>n.x)),y0=Math.min(...ns.map(n=>n.y)),y1=Math.max(...ns.map(n=>n.y));const padX=width<800?68:80,top=65,bottom=45;if(mode==='graph'&&group==='all'){const target=(x1-x0)*(height-top-bottom)/(width-padX*2),scale=target/Math.max(1,y1-y0),cy=(y0+y1)/2;ns.forEach(n=>{n.y=cy+(n.y-cy)*scale;n.anchorY=cy+(n.anchorY-cy)*scale;});y0=Math.min(...ns.map(n=>n.y));y1=Math.max(...ns.map(n=>n.y));}camera.k=Math.max(.06,Math.min(mode==='graph'&&group==='all'?.75:1.8,(width-padX*2)/Math.max(1,x1-x0),(height-top-bottom)/Math.max(1,y1-y0)));camera.x=width/2-(x0+x1)/2*camera.k;camera.y=top+(height-top-bottom)/2-(y0+y1)/2*camera.k;dirty=true;}
    function centerNode(n){viewSize();camera.k=Math.max(camera.k,1.08);camera.x=width/2-n.x*camera.k;camera.y=height/2-n.y*camera.k;dirty=true;wake(.02);}
    function zoom(factor,x=width/2,y=height/2){const k=Math.max(.06,Math.min(4,camera.k*factor)),ratio=k/camera.k;camera.x=x-(x-camera.x)*ratio;camera.y=y-(y-camera.y)*ratio;camera.k=k;dirty=true;draw();wake(.01);}
    function drawMini(){
      const b=bounds(),k=Math.min(100/(b.maxX-b.minX),70/(b.maxY-b.minY)),tx=55-(b.minX+b.maxX)*k/2,ty=40-(b.minY+b.maxY)*k/2;mini.replaceChildren();
      graph.nodes.filter(n=>visibleIds.has(n.id)).forEach(n=>mini.append(svgEl('circle',{cx:n.x*k+tx,cy:n.y*k+ty,r:n.depth<2?1.8:.8,fill:color(n)})));
      mini.append(svgEl('rect',{x:(-camera.x/camera.k)*k+tx,y:(-camera.y/camera.k)*k+ty,width:width/camera.k*k,height:height/camera.k*k,rx:1}));
    }
    function draw(){
      if(dead||mode==='directory')return;if(entryHint.isConnected){const root=graph.byId.get('book');entryHint.style.left=(root.x*camera.k+camera.x)+'px';entryHint.style.top=(root.y*camera.k+camera.y-42)+'px';}world.setAttribute('transform',`translate(${camera.x} ${camera.y}) scale(${camera.k})`);
      const focus=hover||(side.classList.contains('is-open')&&selected!=='book'?selected:null),focusGroup=focus?graph.byId.get(focus)?.group:null,near=focus?new Set(graph.nodes.filter(n=>n.group===focusGroup||n.id===focus).map(n=>n.id)):null,k=camera.k,occupied=[];
      edgeEls.forEach(({line,link:l})=>{line.setAttribute('x1',l.a.x);line.setAttribute('y1',l.a.y);line.setAttribute('x2',l.b.x);line.setAttribute('y2',l.b.y);const lit=!!near&&near.has(l.source)&&near.has(l.target),trunk=l.a.depth<2&&l.b.depth<2;line.classList.toggle('is-active',lit);line.classList.toggle('is-muted',!lit&&!trunk);line.style.opacity=lit?'.8':trunk?'.48':'.1';});
      const ordered=graph.nodes.filter(n=>visibleIds.has(n.id)).sort((a,b)=>Number(b.id===focus)-Number(a.id===focus)||Number(near?.has(b.id))-Number(near?.has(a.id))||a.depth-b.depth);
      for(const n of ordered){
        const el=nodeEls.get(n.id),isFocus=n.id===focus,isNear=near?.has(n.id),sx=n.x*k+camera.x,sy=n.y*k+camera.y;
        const r=(n.radius+(isFocus?1.5:0))/Math.sqrt(k);el.setAttribute('transform',`translate(${n.x} ${n.y})`);
        el.setAttribute('aria-pressed',String(n.id===selected));el.classList.toggle('is-selected',n.id===selected);el.classList.toggle('is-visited',visited.has(n.id));el.setAttribute('aria-label',n.label+(visited.has(n.id)?'，已探索':''));el.classList.toggle('is-neighbor',!!isNear);el.classList.toggle('is-muted',n.depth>1&&!isNear);el.style.opacity=n.depth<2||isNear?'1':'.24';
        el.querySelector('.node-hit').setAttribute('r',Math.max(22/k,r+6/k));el.querySelector('.node-dot').setAttribute('r',r);el.querySelector('.node-glow').setAttribute('r',r*3.2);el.querySelector('.node-ring').setAttribute('r',r+5/k);
        const pin=el.querySelector('.node-pin');pin.setAttribute('r',n.pinned?2.1/k:0);pin.setAttribute('cx',(r+6/k));pin.setAttribute('cy',-r);
        const small=matchMedia('(max-width:800px)').matches;const font=n.id==='book'?(small?23:30):n.depth===1?(small?14:19):n.depth===2?(small?11:12):10;
        const tx=(r*k+8),tw=el.querySelector('text').textContent.length*font,left=sx+tx+tw>width-50,box={x:left?sx-tx-tw-2:sx+tx-2,y:sy-font*.65,w:tw+4,h:font*1.45};
        const collision=occupied.some(b=>box.x<b.x+b.w&&box.x+box.w>b.x&&box.y<b.y+b.h&&box.y+box.h>b.y);
        const candidate=n.depth<2||isFocus||isNear||allLabels||k>.85||(!small&&n.depth===2&&k>.27);
        const show=candidate&&(n.depth<2||allLabels||isFocus||!collision)&&sx>-30&&sx<width-20&&sy>12&&sy<height-15;
        const label=el.querySelector('text');label.setAttribute('font-size',font/k);label.setAttribute('text-anchor',left?'end':'start');label.setAttribute('x',(left?-1:1)*(r+8/k));label.setAttribute('y',small&&n.depth<2?-22/k:0);if(small&&n.depth<2){label.setAttribute('text-anchor','middle');label.setAttribute('x',0);}label.setAttribute('opacity',show?'1':'0');const number=el.querySelector('.node-number');if(number){const nf=small?9:11,nw=number.textContent.length*nf*.6+5;number.setAttribute('font-size',nf/k);number.setAttribute('text-anchor','end');let lx=Number(label.getAttribute('x'));if(small){lx+=nw/2/k;label.setAttribute('x',lx);}else if(!left){lx+=nw/k;label.setAttribute('x',lx);}const textLeft=small?lx-tw/2/k:left?lx-tw/k:lx;number.setAttribute('x',textLeft-5/k);number.setAttribute('y',Number(label.getAttribute('y'))+4/k);number.setAttribute('opacity',show?'.68':'0');}
        if(show)occupied.push(box);
      }
      $('.star-zoom').textContent=Math.round(k*100)+'%';drawMini();dirty=false;
    }
    function loop(){frame=0;if(dead)return;if(!paused&&alpha>.008&&mode!=='directory'){C.step(graph,{alpha,spacing,visibleIds});alpha*=.975;dirty=true;}if(fitPending){fitGraph();fitPending=false;}if(dirty)draw();if(!paused&&alpha>.008&&mode!=='directory')frame=requestAnimationFrame(loop);}
    function wake(a=.2){alpha=Math.max(alpha,a);if(!frame)frame=requestAnimationFrame(loop);}
    function coordinate(e){const r=svg.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
    function graphCoordinate(p){return {x:(p.x-camera.x)/camera.k,y:(p.y-camera.y)/camera.k};}
    function pointerDown(e){
      if(e.button!==0||active)return;if(e.pointerType==='touch'&&!editing)return;
      const hit=e.target.closest('[data-star-node]'),p=coordinate(e),n=hit?graph.byId.get(hit.dataset.starNode):null;
      active={id:e.pointerId,node:n,start:p,previous:p,origin:n?{x:n.x,y:n.y}:null,moved:false};
      if(n)n.dragging=true;svg.setPointerCapture(e.pointerId);svg.focus({preventScroll:true});
    }
    function pointerMove(e){
      if(!active){const id=e.target.closest('[data-star-node]')?.dataset.starNode||null;if(hover!==id&&e.pointerType!=='touch'){hover=id;dirty=true;wake(.01);}return;}
      if(active.id!==e.pointerId)return;const p=coordinate(e),dx=p.x-active.start.x,dy=p.y-active.start.y;
      if(Math.hypot(dx,dy)>4)active.moved=true;
      if(active.moved){if(active.node){const n=active.node;n.x=active.origin.x+dx/camera.k;n.y=active.origin.y+dy/camera.k;if(paused)for(let i=0;i<3;i++)C.step(graph,{alpha:.8,spacing,visibleIds});wake(.75);}else{camera.x+=p.x-active.previous.x;camera.y+=p.y-active.previous.y;wake(.01);}active.previous=p;dirty=true;}
    }
    function pointerEnd(e){if(!active||active.id!==e.pointerId)return;const a=active;active=null;if(a.node){a.node.dragging=false;if(a.moved){a.node.pinned=true;if(a.node.id===selected)renderDetail();dirty=true;wake(.65);}else{select(a.node.id,{fromGraph:true,toggle:true});}}lastPointerClick=performance.now();if(svg.hasPointerCapture(e.pointerId))svg.releasePointerCapture(e.pointerId);}
    listen(svg,'pointerdown',pointerDown);listen(svg,'pointermove',pointerMove);listen(svg,'pointerup',pointerEnd);listen(svg,'pointercancel',e=>{if(active?.node)active.node.dragging=false;active=null;dirty=true;wake(.1);});
    listen(svg,'focusin',e=>{const id=e.target.closest('[data-star-node]')?.dataset.starNode;if(id){hover=id;dirty=true;wake(.01);}});
    listen(svg,'focusout',()=>{hover=null;dirty=true;wake(.01);});
    listen(svg,'pointerleave',()=>{if(!active){hover=null;dirty=true;wake(.01);}});
    listen(svg,'click',e=>{const id=e.target.closest('[data-star-node]')?.dataset.starNode;if(id&&performance.now()-lastPointerClick>250)select(id,{fromGraph:true,toggle:true});});
    listen(svg,'wheel',e=>{if(!e.shiftKey&&!editing)return;e.preventDefault();const p=coordinate(e);zoom(Math.exp(-e.deltaY*.002),p.x,p.y);},{passive:false});
    listen(svg,'keydown',e=>{
      const id=e.target.closest('[data-star-node]')?.dataset.starNode;
      if(id&&(e.key==='Enter'||e.key===' ')){e.preventDefault();select(id,{fromGraph:true,toggle:true});return;}
      if(['+','=','-','0','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();if(e.key==='+'||e.key==='=')zoom(1.2);else if(e.key==='-')zoom(1/1.2);else if(e.key==='0'){fitGraph();wake(.01);}else{const d=e.shiftKey?100:40;camera.x+=e.key==='ArrowRight'?-d:e.key==='ArrowLeft'?d:0;camera.y+=e.key==='ArrowDown'?-d:e.key==='ArrowUp'?d:0;dirty=true;wake(.01);}}
    });
    function expand(){
      expanded=!expanded;work.classList.toggle('is-expanded',expanded);document.body.classList.toggle('star-expanded',expanded);work.setAttribute('role',expanded?'dialog':'region');isolateWorkspace(expanded);if(expanded)work.setAttribute('aria-modal','true');else work.removeAttribute('aria-modal');
      const b=$('[data-star="expand"]');b.textContent=expanded?'× 收起工作区':'⤢ 展开工作区';b.setAttribute('aria-pressed',expanded);b.focus({preventScroll:true});fitPending=true;dirty=true;wake(.01);
    }
    listen(container,'click',e=>{
      const b=e.target.closest('button');if(!b)return;
      if(b.dataset.starSelect){select(b.dataset.starSelect,{locate:mode!=='directory',fromGraph:true});closeSearch();return;}
      if(b.dataset.starView){setMode(b.dataset.starView);return;}
      if(b.dataset.starGroup){group=b.dataset.starGroup;if(mode==='local')mode='graph';if(group!=='all'){if(group!==selected){trail.push(selected);if(trail.length>30)trail.shift();}selected=group;visited.add(selected);notifySelection(graph.byId.get(selected));renderDetail();}rebuild();return;}
      const action=b.dataset.star;if(!action)return;if(action==='switch-view'){setMode(mode==='directory'?'graph':'directory');return;}if(mode==='directory'&&['zoom-in','zoom-out','fit','reset','locate'].includes(action)){if(action==='zoom-in')tree.zoom(1.3);else if(action==='zoom-out')tree.zoom(1/1.3);else tree.fit();if(action==='locate')closeDetail();return;}if(action==='refresh-questions'){questionOffset=(questionOffset+2)%bookQuestions.length;$('#book-question-options').innerHTML=questionOptions();return;}if(action==='close-detail'){closeDetail();return;}
      if(action==='previous'&&trail.length){select(trail.pop(),{locate:mode!=='directory',track:false});focusDetail();return;}
      if(action==='framework'){closeDetail();group='all';depth=99;treeDepth=99;$('#star-depth').value='99';if(mode==='directory')renderDirectory();else setMode('directory');tree.fit();}if(action==='expand')expand();if(action==='zoom-in')zoom(1.3);if(action==='zoom-out')zoom(1/1.3);if(action==='fit'){fitGraph();wake(.01);}if(action==='locate'){closeDetail();if(mode==='directory')mode='graph';if(!visibleIds.has(selected)){depth=99;group='all';$('#star-depth').value='99';}rebuild({fit:false});centerNode(graph.byId.get(selected));focusVisual();stage.scrollIntoView({block:'center',behavior:'instant'});}
      if(action==='pause'&&!reduced.matches&&motion&&!document.body.classList.contains('still')){paused=!paused;syncMotion();dirty=true;wake(.5);}
      if(action==='reset'){const fresh=createGraph();for(const n of graph.nodes){const f=fresh.byId.get(n.id);Object.assign(n,{x:f.x,y:f.y,vx:0,vy:0,pinned:false,dragging:false});}renderDetail();rebuild();}
      if(action==='pin'){const n=graph.byId.get(selected);n.pinned=!n.pinned;renderDetail();$('[data-star="pin"]').focus({preventScroll:true});dirty=true;wake(.4);}
      if(action==='focus'){closeDetail();setMode('local');stage.scrollIntoView({block:'center',behavior:'instant'});focusVisual();}
      if(action==='touch'){editing=!editing;tree.setTouch(editing);stage.classList.toggle('is-touch-edit',editing);b.setAttribute('aria-pressed',editing);b.textContent=editing?'完成拖拽 · 恢复滚动':'启用拖拽';}
    });
    listen(container,'change',e=>{const el=e.target;if(el.id==='star-depth'){depth=Number(el.value);rebuild();}if(el.id==='star-hops'){hops=Number(el.value);rebuild();}if(el.id==='star-cross'){cross=el.checked;rebuild({fit:mode==='local'});}if(el.id==='star-labels'){allLabels=el.checked;dirty=true;wake(.01);}});
    listen($('#star-spacing'),'input',e=>{spacing=Number(e.target.value)/100;for(let i=0;i<30;i++)C.step(graph,{alpha:.7,spacing,visibleIds});fitGraph();dirty=true;wake(.5);});
    function search(){
      const q=$('#star-search').value.trim().toLowerCase(),r=$('#star-search-results');
      r.hidden=!q;$('#star-search').setAttribute('aria-expanded',String(!!q));
      if(!q){$('#star-search-status').textContent='';return;}
      const results=graph.nodes.filter(n=>(n.label+' '+n.summary).toLowerCase().includes(q));
      r.innerHTML=results.length?results.slice(0,12).map(n=>`<button data-star-select="${n.id}">${esc(n.label)}<small>${esc(graph.byId.get(n.group)?.label||'全书导航')}</small></button>`).join(''):'<p>没有找到。可以试试「时间」「影响」「倾听」。</p>';
      $('#star-search-status').textContent=results.length?`找到 ${results.length} 个概念${results.length>12?'，显示前 12 项':''}，可按上下方向键选择。`:'没有找到匹配概念。';
    }
    listen($('#star-search'),'input',search);
    listen($('.star-search-wrap'),'keydown',e=>{
      if(e.isComposing||e.keyCode===229)return;
      const input=$('#star-search'),results=$('#star-search-results');
      if(e.key==='Escape'&&!results.hidden){e.preventDefault();e.stopPropagation();closeSearch();input.focus({preventScroll:true});return;}
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){
        if(results.hidden&&input.value.trim())search();
        const buttons=[...results.querySelectorAll('button')];if(results.hidden||!buttons.length)return;
        e.preventDefault();const index=buttons.indexOf(document.activeElement),direction=e.key==='ArrowDown'?1:-1;
        const next=index<0?(direction===1?0:buttons.length-1):(index+direction+buttons.length)%buttons.length;
        buttons[next].focus();return;
      }
      if(e.key==='Enter'&&e.target===input&&!results.hidden){const first=results.querySelector('button');if(first){e.preventDefault();first.click();}}
    });
    listen($('.star-search-wrap'),'focusout',e=>{if(e.relatedTarget&&!$('.star-search-wrap').contains(e.relatedTarget))closeSearch();});
    listen(document,'pointerdown',e=>{if(!e.target.closest('.star-search-wrap'))closeSearch();});
    listen(document,'focusin',e=>{if(expanded&&!work.contains(e.target))$('[data-star="expand"]').focus({preventScroll:true});});
    listen(document,'keydown',e=>{
      if(e.isComposing||e.keyCode===229)return;
      if(e.key==='Escape'){if(side.classList.contains('is-open')){e.preventDefault();closeDetail();return;}if(expanded){e.preventDefault();expand();return;}if(editing){editing=false;tree.setTouch(false);stage.classList.remove('is-touch-edit');const b=$('[data-star="touch"]');b.setAttribute('aria-pressed','false');b.textContent='启用拖拽';}closeSearch();}
      if(expanded&&e.key==='Tab'){const fs=[...work.querySelectorAll('button,input,select,a,summary,[tabindex="0"]')].filter(el=>el.getClientRects().length&&!el.disabled);const first=fs[0],last=fs[fs.length-1];if(e.shiftKey&&(document.activeElement===first||!work.contains(document.activeElement))){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
    });
    let firstResize=true;const resize=new ResizeObserver(()=>{viewSize();if(firstResize&&saved&&Math.abs(width-saved.width)<2&&Math.abs(height-saved.height)<2){firstResize=false;dirty=true;wake(.001);return;}firstResize=false;if(mode==='directory')tree.fit();fitPending=true;dirty=true;wake(.01);});resize.observe(stage);
    listen(reduced,'change',syncMotion);
    let lastStill=document.body.classList.contains('still');
    const preferenceObserver=new MutationObserver(()=>{const still=document.body.classList.contains('still');if(still!==lastStill){lastStill=still;motion=!still;syncMotion();}});
    preferenceObserver.observe(document.body,{attributes:true,attributeFilter:['class']});
    viewSize();renderDetail();rebuild({fit:!saved});if(saved){tree.restore(saved.tree);fitPending=false;alpha=0;dirty=true;draw();}syncMotion();
    return {setMotion(value){motion=value!==false;syncMotion();},destroy(){sessionView={selected,mode,group,depth,hops,cross,allLabels,spacing,paused,graphDepth,treeDepth,camera:{...camera},width,height,trail:[...trail],visited:[...visited],tree:tree.snapshot(),nodes:Object.fromEntries(graph.nodes.map(n=>[n.id,{x:n.x,y:n.y,anchorX:n.anchorX,anchorY:n.anchorY,vx:0,vy:0,pinned:n.pinned}]))};dead=true;clearTimeout(hintTimer);clearTimeout(transitionTimer);abort.abort();resize.disconnect();preferenceObserver.disconnect();cancelAnimationFrame(frame);isolateWorkspace(false);document.body.classList.remove('star-expanded');}};
  }
  window.StarMap={mount};
})();

