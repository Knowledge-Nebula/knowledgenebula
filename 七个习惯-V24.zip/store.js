(function(root){
  'use strict';
  const KEY='seven-habits-reading-room-v1',PREFS=KEY+'-preferences';
  const makeDefault=()=>({version:1,persist:true,theme:'black',paletteVersion:2,motion:true,reading:{size:'normal',measure:'standard',leading:'normal'},read:[],entries:{},last:null,coach:{topic:'h1',context:'',mode:'reflect'}});
  const str=(v,max=8000)=>typeof v==='string'?v.slice(0,max):'';
  function clean(raw){
    const s=makeDefault();
    if(!raw||raw.version!==1) return s;
    s.persist=raw.persist!==false;s.theme=raw.paletteVersion===2&&['black','light'].includes(raw.theme)?raw.theme:'black';s.motion=raw.motion!==false;
    s.reading={size:raw.reading?.size==='large'?'large':'normal',measure:raw.reading?.measure==='narrow'?'narrow':'standard',leading:raw.reading?.leading==='relaxed'?'relaxed':'normal'};
    s.read=Array.isArray(raw.read)?[...new Set(raw.read.filter(x=>/^h[1-7]$/.test(x)))]:[];
    for(let n=1;n<=7;n++){const id='h'+n,e=raw.entries&&raw.entries[id];if(e&&typeof e==='object')s.entries[id]={situation:str(e.situation),action:str(e.action),review:str(e.review),date:/^\d{4}-\d{2}-\d{2}$/.test(e.date)?e.date:'',choice:Number.isInteger(e.choice)&&e.choice>=0&&e.choice<3?e.choice:null};}
    if(raw.last&&/^h[1-7]$/.test(raw.last.topic)&&['map','insight','practice','coach'].includes(raw.last.page))s.last={page:raw.last.page,topic:raw.last.topic,nodeId:/^[a-z0-9_-]{1,80}$/.test(raw.last.nodeId||'')?raw.last.nodeId:null};
    if(raw.coach){s.coach={topic:/^h[1-7]$/.test(raw.coach.topic)?raw.coach.topic:'h1',context:str(raw.coach.context),mode:['reflect','roleplay','review'].includes(raw.coach.mode)?raw.coach.mode:'reflect'};}
    return s;
  }
  function create(storage){
    let available=!!storage,reason='';let state=makeDefault();
    try {const raw=storage&&storage.getItem(KEY);if(raw){const parsed=JSON.parse(raw);state=clean(parsed);if(parsed.version!==1)reason='旧版记录未自动转换。';}const prefs=storage&&storage.getItem(PREFS);if(prefs){const p=JSON.parse(prefs);state.persist=p.persist!==false;state.theme=p.paletteVersion===2&&['black','light'].includes(p.theme)?p.theme:'black';state.motion=p.motion!==false;state.reading=clean({version:1,reading:p.reading}).reading;if(!state.persist){state.read=[];state.entries={};state.last=null;state.coach=makeDefault().coach;}}}
    catch(e){reason='无法读取本地记录，仍可在本页练习和导出。';available=false;}
    return {state,key:KEY,get available(){return available;},get reason(){return reason;},save(){try{if(!storage)throw new Error('storage unavailable');storage.setItem(PREFS,JSON.stringify({persist:state.persist,theme:state.theme,paletteVersion:2,motion:state.motion,reading:state.reading}));if(state.persist)storage.setItem(KEY,JSON.stringify(clean(state)));available=true;reason='';return state.persist;}catch(e){available=false;reason='保存失败。请导出备份，刷新可能丢失当前记录。';return false;}},setPersist(value){state.persist=!!value;if(!value){try{if(storage)storage.removeItem(KEY);}catch(e){available=false;}}return this.save();},clear(){const theme=state.theme,motion=state.motion,persist=state.persist,reading=state.reading;Object.assign(state,makeDefault(),{theme,motion,persist,reading});try{if(storage)storage.removeItem(KEY);}catch(e){available=false;}this.save();},snapshot(){return clean(state);}};
  }
  root.ReadingStore={create,clean,makeDefault};
})(typeof window!=='undefined'?window:globalThis);
