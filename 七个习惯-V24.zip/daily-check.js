(function(){
'use strict';
const habits=['积极主动','以终为始','要事第一','双赢思维','知彼解己','统合综效','不断更新'];
const questions=[
['计划被临时打乱时，我先找出还能由自己决定的一步，再回应。','遇到反复困扰我的事，我做过一件能影响结果的小事，而不只是抱怨。'],
['答应一件新任务前，我想过：做成什么样，才算值得？','安排时间时，我参考过自己重视的角色或长期方向，而不只是眼前要求。'],
['即使没有人催，我也给一件重要但不紧急的事留出了时间。','临时请求挤进来时，我比较过它和原定要事，再决定接受、调整或拒绝。'],
['有分歧时，我把双方在意的结果都说清楚，再讨论方案。','达成约定前，我确认过双方是否真能接受；不合适时，也允许暂不合作。'],
['别人表达不满时，我先核对自己有没有听懂，再解释或建议。','表达自己的想法时，我也照顾到对方的关注点，让对方更容易理解。'],
['别人意见不同的时候，我认真找过其中能补足我盲点的部分。','合作卡住时，我和对方一起想过一个超出原来两种选择的新方案。'],
['忙碌时，我仍给睡眠、活动或恢复精力留出了一点空间。','过去两周，我为学习、重要关系或价值回顾安排过一个实际动作。']
].flat();
const actions=['把一件烦心事分成“暂时改变不了”和“今天能做的一步”。','挑一件正在忙的事，用一句话写清你希望它带来什么。','给一件重要但不紧急的事，在本周留出一小段具体时间。','在一次小协商中，分别问清双方最在意的结果。','下一次对话，先用自己的话核对对方意思，再表达看法。','和合作者各说一个原方案没照顾到的需要，再一起想第三种办法。','选身体、学习、关系或价值中的一个方面，安排一次能做到的小更新。'];
let answers=Array(14).fill(null),index=0,finished=false;
const labels=['很少这样','偶尔这样','经常这样','暂时没有这样的情境'];
function mount(host){
 function paint(){const count=answers.filter(x=>x!==null).length;
 host.innerHTML=`<div class="check-shell"><a href="#practice">← 返回生活练习</a><header><div class="eyebrow">七个习惯 · 原创行为回顾</div><h1 tabindex="-1">日常对照</h1><p>回想过去两周的具体经历，看看哪些动作已经出现，哪些值得再试一次。</p><p class="hint">14 道原创题，约 3 分钟。不判定你是否“具备”某种人格，也不是专业测评。回答只在本次页面会话中保留，刷新后清空。</p></header>${finished?result():`<section class="check-card"><div class="check-progress"><span>第 ${index+1} / 14 题</span><span>已回答 ${count} 题</span></div><progress max="14" value="${count}" aria-label="回答进度"></progress><span class="tag">${habits[Math.floor(index/2)]}</span><h2 tabindex="-1">${questions[index]}</h2><div class="check-options" role="group" aria-label="过去两周的情况">${labels.map((label,i)=>`<button data-answer="${i}" aria-pressed="${answers[index]===i}">${label}<span aria-hidden="true">${answers[index]===i?'✓':'○'}</span></button>`).join('')}</div><div class="check-nav"><button data-check="back" ${index===0?'disabled':''}>上一题</button><button class="button" data-check="next" ${answers[index]===null?'disabled':''}>${index===13?'看看我的回顾':'下一题 →'}</button></div></section>`}</div>`;
 }
 function result(){return `<section class="check-result"><h2 tabindex="-1">从一个动作开始就好</h2><p>下面只对照你这次的回答：一项习惯只有两道题，不能代表它的全部。没有经历的情境不会被当作不足，也不计算总分。</p><div class="check-results">${habits.map((name,h)=>{const pair=answers.slice(h*2,h*2+2),valid=pair.filter(x=>x!==3),less=pair.some(x=>x===0||x===1);const title=!valid.length?'先留意一个真实情境':less?'可以先试一个小动作':valid.length===1?'已有一个可延续的动作':'已有可以延续的动作';return `<article><span class="eyebrow">0${h+1} / ${name}</span><h3>${title}</h3><p class="hint">${pair.map((a,j)=>`第 ${h*2+j+1} 题：${labels[a]}`).join('；')}</p><p>${actions[h]}</p><div><a href="#practice/h${h+1}">试一份练习 ↗</a> · <a href="#insight/h${h+1}">读懂这个习惯</a></div></article>`}).join('')}</div><div class="check-nav"><button data-check="edit">回看并修改回答</button><button data-check="reset">清空并重新开始</button></div></section>`;}
 host.onclick=e=>{const option=e.target.closest('[data-answer]');if(option){answers[index]=Number(option.dataset.answer);paint();host.querySelector(`[data-answer="${answers[index]}"]`).focus({preventScroll:true});return;}const action=e.target.closest('[data-check]')?.dataset.check;if(!action)return;if(action==='back')index=Math.max(0,index-1);if(action==='next'){if(answers[index]===null)return;if(index<13)index++;else finished=true;}if(action==='edit'){finished=false;index=0;}if(action==='reset'){answers=Array(14).fill(null);index=0;finished=false;}paint();host.querySelector('.check-card h2,.check-result h2')?.focus({preventScroll:true});};paint();
}
window.DailyCheck={mount};
})();
